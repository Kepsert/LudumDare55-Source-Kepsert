using LDtkUnity;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Killer : MonoBehaviour, IKiller
{

    public bool ActiveKiller()
    {
        return true;
    }
}
