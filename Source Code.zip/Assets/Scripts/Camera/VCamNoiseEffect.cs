using Cinemachine;
using Messaging;
using Messaging.Messages;
using Misc;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VCamNoiseEffect : MonoBehaviour
{
    private CinemachineVirtualCamera _cineCam;
    private CinemachineBasicMultiChannelPerlin _noise;

    Guid _shakeTimer;

    private void Awake()
    {
        _cineCam = GetComponent<CinemachineVirtualCamera>();
        _noise = _cineCam.GetCinemachineComponent<CinemachineBasicMultiChannelPerlin>();
    }

    private void OnEnable()
    {
        MessageHub.Subscribe<LevelStartedMessage>(this, LevelStarted);
        MessageHub.Subscribe<LevelEndedMessage>(this, LevelEnded);
    }

    
    private void OnDisable()
    {
        MessageHub.Unsubscribe<LevelStartedMessage>(this);
        MessageHub.Unsubscribe<LevelEndedMessage>(this);
    }

    private void LevelStarted(LevelStartedMessage obj)
    {
        
    }

    private void LevelEnded(LevelEndedMessage obj)
    {
        ResetNoise();
        Timer.Instance.RemoveTimer(_shakeTimer);
    }


    public void ResetNoise()
    {
        Timer.Instance.RemoveTimer(_shakeTimer);
        _noise.m_AmplitudeGain = 0;
        _noise.m_FrequencyGain = 0;
    }

    public void Noise(float duration, float strength, float frequency)
    {
        Timer.Instance.RemoveTimer(_shakeTimer);
        _shakeTimer = Timer.Instance.AddTimer(duration, () =>
        {
            ResetNoise();
        });
        _noise.m_AmplitudeGain = strength;
        _noise.m_FrequencyGain = frequency;
    }
}
