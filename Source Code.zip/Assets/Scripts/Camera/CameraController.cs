using Cinemachine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
    public static CameraController Instance;

    [SerializeField] VCamNoiseEffect _vcne = null;
    [SerializeField] CinemachineVirtualCamera _cineCam = null;

    [SerializeField] float _moveAmount = 0.25f;
    [SerializeField] float _moveSpeed = 5.0f;

    private CinemachineFramingTransposer _framingTransposer;
    private float _originalScreenY;
    private int _moveDirection;

    [SerializeField] ParticleSystem _dustDrops = null;

    bool _lookingDown = false;
    
    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            DestroyImmediate(this);
        }
    }

    private void Start()
    {
        _framingTransposer = _cineCam.GetCinemachineComponent<CinemachineFramingTransposer>();
        _originalScreenY = _framingTransposer.m_ScreenY;
    }

    public void ScreenShake(float duration, float strength, float frequency)
    {
        if (_vcne != null && GameSettings.Instance.Screenshake.Value)
        {
            _vcne.Noise(duration, strength, frequency);
        }
    }

    public void ToggleParticles(bool value)
    {
        if (value)
        {
            _dustDrops.Play();
        }
        else
        {
            _dustDrops.Stop();
        }
    }

    private void Update()
    {
        if (_moveDirection == -1)
        {
            float targetScreenY = _originalScreenY - _moveAmount * 1.15f;

            _framingTransposer.m_ScreenY = Mathf.Lerp(_framingTransposer.m_ScreenY, targetScreenY, _moveSpeed * Time.deltaTime);
        }
        else if (_moveDirection == 1)
        {
            float targetScreenY = _originalScreenY + _moveAmount;

            _framingTransposer.m_ScreenY = Mathf.Lerp(_framingTransposer.m_ScreenY, targetScreenY, _moveSpeed * Time.deltaTime);
        }
        else
        {
            _framingTransposer.m_ScreenY = Mathf.Lerp(_framingTransposer.m_ScreenY, _originalScreenY, _moveSpeed * 2 * Time.deltaTime);
        }
    }

    public void ResetScreenshake()
    {
        _vcne.ResetNoise();
    }

    public void StopFollowing()
    {
        _cineCam.m_Follow = null;
    }

    public void FollowNewTarget(Transform transform)
    {
        _cineCam.m_Follow = transform;
    }

    public void LookDown(int moveDirection)
    {
        _moveDirection = moveDirection;
    }
}
