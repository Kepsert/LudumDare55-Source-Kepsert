using System.Collections.Generic;
using UnityEngine;

public class SoundController : Singleton<SoundController>
{
    private SoundManager _soundManager;

    public List<AudioClip> _soundClips = new List<AudioClip>();
    private Dictionary<string, AudioClip> _soundDictionary;

    [SerializeField] FloatVariable _masterVolumeVariable;
    [SerializeField] FloatVariable _sfxVolumeVariable;

    [SerializeField] int _initialPoolSize = 5;
    [SerializeField] Transform _parentTransform;

    private void OnEnable()
    {
        _masterVolumeVariable._changedEvent += MasterVolumeChanged;
        _sfxVolumeVariable._changedEvent += MusicVolumeChanged;
    }

    private void OnDisable()
    {
        _masterVolumeVariable._changedEvent -= MasterVolumeChanged;
        _sfxVolumeVariable._changedEvent -= MusicVolumeChanged;
    }

    private void MasterVolumeChanged(float obj)
    {
        UpdateVolume();
    }

    private void MusicVolumeChanged(float obj)
    {
        UpdateVolume();
    }

    private void UpdateVolume()
    {
        _soundManager.UpdateVolume(_masterVolumeVariable.Value * _sfxVolumeVariable.Value);
    }

    private void Start()
    {
        ISoundPlayer player = new UnitySoundPlayer(_soundClips[0], _initialPoolSize, _parentTransform);

        _soundDictionary = new Dictionary<string, AudioClip>();
        foreach (var clip in _soundClips)
        {
            if (!_soundDictionary.ContainsKey(clip.name))
            {
                _soundDictionary.Add(clip.name, clip);
            }
        }

        _soundManager = new SoundManager(player, _soundDictionary, _sfxVolumeVariable.Value * _masterVolumeVariable.Value);
    }

    public void PlaySoundByName(string name, float pitch = 1.0f)
    {
        _soundManager.PlaySound("SFX_" + name, pitch);
    }

    public void ChangeMusic(string musicName)
    {
        SoundtrackManager.Instance.PlayTrack(musicName);
    }

    public void StopMusic()
    {
        SoundtrackManager.Instance.StopMusic();
    }
}
