using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Parallax : MonoBehaviour
{
    float _length;
    float _height;
    private float _startPositionX;
    private float _startPositionY;
    private Camera _cam;

    [SerializeField] private float _parallaxEffectX;
    [SerializeField] private float _parallaxEffectY;

    private void Start()
    {
        if (_cam==null)
        {
            _cam = GameObject.FindGameObjectWithTag("MainCamera").GetComponent<Camera>();
        }
        _startPositionX = transform.position.x;
        _startPositionY = transform.position.y;
        _length = GetComponent<SpriteRenderer>().bounds.size.x;
        _height = GetComponent<SpriteRenderer>().bounds.size.y;
    }

    private void Update()
    {
        float tempX = (_cam.transform.position.x * (1 - _parallaxEffectX));
        float tempY = (_cam.transform.position.y * (1 - _parallaxEffectY));
        float distanceX = (_cam.transform.position.x * _parallaxEffectX);
        float distanceY = (_cam.transform.position.y * _parallaxEffectY);

        transform.position = new Vector3(_startPositionX + distanceX, _startPositionY + distanceY, transform.position.z);

        if (tempX > _startPositionX + _length)
        {
            _startPositionX += _length;
        }
        else if (tempX < _startPositionX - _length)
        {
            _startPositionX -= _length;
        }

        if (tempY > _startPositionY + _height)
        {
            _startPositionY += _height;
        }
        else if (tempY < _startPositionY - _height)
        {
            _startPositionY -= _height;
        }
    }
}
