using DG.Tweening;
using Messaging;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FeedbackArrowHover : MonoBehaviour
{
    Sequence _hover;

    private void Awake()
    {
        SetTween();
    }

    private void OnDisable()
    {
        _hover.Kill();
    }

    private void SetTween()
    {
        _hover = DOTween.Sequence();
        Vector3 origPos = this.transform.localPosition;
        Vector3 targetPos = this.transform.localPosition + new Vector3(0, 0.25f, 0);
        _hover.Append(this.transform.DOLocalMove(targetPos, 1.25f).SetEase(Ease.OutSine));
        _hover.Append(this.transform.DOLocalMove(origPos, 1.25f).SetEase(Ease.OutSine));
        _hover.SetLoops(-1);
    }
}
