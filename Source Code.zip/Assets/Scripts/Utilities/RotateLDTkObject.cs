using LDtkUnity;
using UnityEngine;

public class RotateObject : MonoBehaviour, ILDtkImportedFields
{
    [SerializeField] Rotation _rotation = Rotation.Up;

    public void OnLDtkImportFields(LDtkFields fields)
    {
        _rotation = fields.GetEnum<Rotation>("Rotation");

        switch (_rotation)
        {
            case Rotation.Up: this.transform.eulerAngles = new Vector3(0, 0, 0); break;
            case Rotation.Down: this.transform.eulerAngles = new Vector3(0, 0, 180); break;
            case Rotation.Left: this.transform.localRotation = Quaternion.Euler(0, 0, 90); break;
            case Rotation.Right: this.transform.localRotation = Quaternion.Euler(0, 0, 270); break;
        }
    }
}