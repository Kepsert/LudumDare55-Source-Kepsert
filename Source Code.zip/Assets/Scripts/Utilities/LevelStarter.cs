using LDtkUnity;
using Messaging;
using Messaging.Messages;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelStarter : MonoBehaviour, ILDtkImportedFields
{
    [SerializeField] string _musicName = null;

    public void OnLDtkImportFields(LDtkFields fields)
    {
        _musicName = fields.GetString("Music");
    }

    private void Start()
    {
        MessageHub.Publish(new LevelStartedMessage());
        
        if (GameController.Instance.State is not GameState.Dialogue || GameController.Instance.State is not GameState.Cutscene)
        {
            CutsceneTrigger cutsceneTrigger = FindObjectOfType<CutsceneTrigger>();
            if (cutsceneTrigger == null || !cutsceneTrigger._playOnStart || GameController.Instance.Mode is GameMode.Speedrun)
            {
                SoundController.Instance.ChangeMusic(_musicName);
                GameController.Instance.SetGameState(GameState.Playing);
            }
        }

        if (GameController.Instance.Mode is GameMode.Normal)
        {
            int level = SceneManager.GetActiveScene().buildIndex;
            PlayerPrefs.SetInt("SavedGame", level);
        }
    }
}
