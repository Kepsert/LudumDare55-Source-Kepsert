using Cinemachine;
using LDtkUnity;
using Player;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BaseLevel : MonoBehaviour, ILDtkImportedLevel
{
    [SerializeField] private Transform _top = null;
    [SerializeField] private Transform _bottom = null;
    [SerializeField] private Transform _left = null;
    [SerializeField] private Transform _right = null;

    private PolygonCollider2D _polygonCollider2D;
    CinemachineVirtualCamera _cineCamera = null;

    public void OnLDtkImportLevel(Level level)
    {
        _polygonCollider2D = GetComponent<PolygonCollider2D>();
        var requirements = transform.Find("Requirements");
        if (requirements == null)
        {
            Debug.LogWarning("No requirements found");
            return;
        }

        var confiner = requirements.GetComponentInChildren<CinemachineConfiner2D>();
        if (confiner == null)
        {
            Debug.LogWarning("No confiner found");
            return;
        }

        confiner.m_BoundingShape2D = GetComponent<PolygonCollider2D>();
        _cineCamera = GetComponentInChildren<CinemachineVirtualCamera>();
        _cineCamera.m_Follow = (FindObjectOfType<PlayerController>().transform);

        var collider = transform.GetComponent<Collider2D>();
        var extents = collider.bounds.extents;
        _top.position = collider.bounds.center + new Vector3(0, extents.y + .5f, 0);
        _left.position = collider.bounds.center + new Vector3(-extents.x, 0, 0);
        _right.position = collider.bounds.center + new Vector3(extents.x, 0, 0);
        _bottom.position = collider.bounds.center + new Vector3(0, -extents.y - 2.5f, 0);

        var points = _polygonCollider2D.points;
        _polygonCollider2D.points = new[]
        {
            points[0] + new Vector2(1, -1),
            points[1] + new Vector2(1,1),
            points[2] + new Vector2(-2, 1),
            points[3] + new Vector2(-1, -1)
        };

        CompositeCollider2D[] compositeColliders = GetComponentsInChildren<CompositeCollider2D>();
        foreach (CompositeCollider2D colliders in compositeColliders)
        {
            colliders.geometryType = CompositeCollider2D.GeometryType.Polygons;
        }
    }
}
