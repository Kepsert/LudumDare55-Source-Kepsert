using Messaging;
using Messaging.Messages;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScriptablesResetter : MonoBehaviour
{
    [SerializeField] List<FloatVariable> _resettableFloaties = new List<FloatVariable>();
    [SerializeField] List<BoolVariable> _resettableBoolies = new List<BoolVariable>();

    private void OnEnable()
    {
        MessageHub.Subscribe<LevelStartedMessage>(this, NewLevel);
    }

    private void OnDisable()
    {
        MessageHub.Unsubscribe<LevelStartedMessage>(this);
    }

    private void NewLevel(LevelStartedMessage obj)
    {
        ClearList();
    }

    private void Awake()
    {
        ClearList();
    }

    private void ClearList()
    {
        foreach (FloatVariable floatie in _resettableFloaties)
        {
            floatie.Initialize();
        }
    }
}
