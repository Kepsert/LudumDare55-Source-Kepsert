using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoroutineUtility : MonoBehaviour
{
    public static CoroutineUtility Instance;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            DestroyImmediate(this);
        }
    }
}
