using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyUtility : MonoBehaviour, IDestroyable
{
    public void Destroy(float duration)
    {
        StartCoroutine(DestroyObject(duration));
    }

    private IEnumerator DestroyObject(float duration)
    {
        yield return new WaitForSeconds(duration);
        Destroy(this.gameObject);
    }
}
