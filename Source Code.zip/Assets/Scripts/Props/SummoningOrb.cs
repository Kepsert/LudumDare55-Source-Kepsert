using Misc;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SummoningOrb : MonoBehaviour, ICollectible
{
    [SerializeField] FloatVariable _energyVariable = null;
    [SerializeField] SpriteRenderer _renderer = null;
    [SerializeField] Collider2D _collider = null;
    [SerializeField] Animator _anim = null;
    [SerializeField] ParticleSystem _sparkleParkles = null;

    Guid _pickUpTimer;

    const string _activeAnimName = "Active";
    const string _pickAnimName = "Pick";

    const float _pickAnimDuration = .6f;

    public void Reset()
    {
        Timer.Instance.RemoveTimer(_pickUpTimer);
        _renderer.enabled = true;
        Timer.Instance.AddTimer(0.1f, () =>
        {
            _collider.enabled = true;
        });
        _anim.Play(_activeAnimName);
        _sparkleParkles.Play();
    }

    ICollectible ICollectible.Collect()
    {
        if (_energyVariable != null)
        {
            if (_energyVariable.Value == 0)
            {
                _energyVariable.ChangeValue(_energyVariable.Value + 1, true);
                _collider.enabled = false;
                _anim.Play(_pickAnimName);
                _sparkleParkles.Stop();
                _pickUpTimer = Timer.Instance.AddTimer(_pickAnimDuration, () =>
                {
                    _renderer.enabled = false;
                });
                return this;
            }
            else
            {
                return null;
            }
        }
        else
        {
            Debug.LogWarning("SUMMONING ORB: Missing Energy Variable");
        }
        return null;
    }
}
