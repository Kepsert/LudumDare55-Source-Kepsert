using LDtkUnity;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimeSpaceBlock : MonoBehaviour, ITimeAffected, ILDtkImportedFields
{
    [SerializeField] BoxCollider2D _collider = null;
    [SerializeField] Animator _anim = null;
    [SerializeField] bool _startsInactive = true;

    public void OnLDtkImportFields(LDtkFields fields)
    {
        _startsInactive = fields.GetBool("Start");
    }

    void Awake()
    {
        if (!_startsInactive)
        {
            _collider.enabled = true;
            _anim.Play("Active");
        }
    }

    public void Toggle(bool value)
    {
        if (_startsInactive)
        {
            _collider.enabled = value;
            if (value)
            {
                _anim.Play("Active");
            }
            else
            {
                _anim.Play("Idle");
            }
        }
        if (!_startsInactive)
        {
            _collider.enabled = !value;
            if (!value)
            {
                _anim.Play("Active");
            }
            else
            {
                _anim.Play("Idle");
            }
        }
    }
}
