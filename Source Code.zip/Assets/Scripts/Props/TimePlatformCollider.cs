using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimePlatformCollider : MonoBehaviour, ITimeAffected
{
    [SerializeField] TimePlatform _timePlatform = null;

    public void Toggle(bool value)
    {
        _timePlatform.Toggle(value);
    }
}
