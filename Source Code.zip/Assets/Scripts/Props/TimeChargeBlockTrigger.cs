using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimeChargeBlockTrigger : MonoBehaviour, ITimeAffected
{
    [SerializeField] TimeChargeBlock _timeChargeBlock = null;

    public void Toggle(bool value)
    {
        _timeChargeBlock.Toggle(value);
    }
}
