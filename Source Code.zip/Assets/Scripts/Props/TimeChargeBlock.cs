using Misc;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimeChargeBlock : MonoBehaviour
{
    [SerializeField] BoxCollider2D _collider = null;
    [SerializeField] Animator _anim = null;

    const float _activeTime = 5f;

    bool _active = false;

    Coroutine _drainCoroutine = null;

    void OnDisable()
    {
        _drainCoroutine = null;
        StopAllCoroutines();
    }



    public void Toggle(bool value)
    {
        if (value)
        {
            if (!_active)
            {
                StopAllCoroutines();
                _drainCoroutine = null;
                _active = true;
                _collider.enabled = true;
                _anim.Play("Full");
            }
        }
        else
        {
            if (_drainCoroutine == null)
            {
                StartCoroutine(DrainCoroutine());
            }
        }
    }

    IEnumerator DrainCoroutine()
    {
        _active = false;
        _anim.Play("Drain");
        yield return new WaitForSeconds(_activeTime);
        _collider.enabled = false;
        _anim.Play("Idle");
        _drainCoroutine = null;
    }
}
