using LDtkUnity;
using Misc;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimePlatform : MonoBehaviour, ITimeAffected, ILDtkImportedFields, IParentable
{
    [SerializeField] List<Transform> _waypoints = new List<Transform>();
    [SerializeField] float _movementSpeed = 5f;
    [SerializeField] int _startingWaypoint = 0;
    [SerializeField] float _waitTime = 0;
    bool _isActive = false;
    [SerializeField] Animator _anim = null;

    Vector3 _startPosition;
    int _waypointIndex;
    Guid _waitTimer;

    [SerializeField] Collider2D _triggerCollider = null;

    public void OnLDtkImportFields(LDtkFields fields)
    {
        _startingWaypoint = fields.GetInt("StartingWaypoint");
        _waitTime = fields.GetFloat("WaitTime");
        _movementSpeed = fields.GetFloat("MovementSpeed");

        var linkedEntities = fields.GetEntityReferenceArray("Waypoints");
        if (linkedEntities.Length <= 1)
        {
            Debug.LogWarning("NotEnoughWaypoints");
            return;
        }

        else if (linkedEntities.Length > 1)
        {
            foreach (var entity in linkedEntities)
            {
                _waypoints.Add(entity.GetEntity().transform);
            }
        }
    }

    private void Awake()
    {
        _startPosition = this.transform.position;
        _waypointIndex = _startingWaypoint;

        if (_triggerCollider == null)
        {
            _triggerCollider = GetComponent<Collider2D>();
        }
    }

    void OnDisable()
    {
        Timer.Instance.RemoveTimer(_waitTimer);
    }

    private void FixedUpdate()
    {
        if (_isActive)
        {
            _waypointIndex = 1;
            if (Vector2.Distance(_waypoints[1].transform.position, transform.position) < .1f)
            {
                this.transform.position = _waypoints[1].transform.position;
            }
            transform.position = Vector2.MoveTowards(transform.position, _waypoints[_waypointIndex].transform.position, Time.deltaTime * _movementSpeed);
        }
        else
        {
            _waypointIndex = 0;
            if (Vector2.Distance(_waypoints[0].transform.position, transform.position) < .1f)
            {
                this.transform.position = _waypoints[0].transform.position;
            }
            transform.position = Vector2.MoveTowards(transform.position, _waypoints[_waypointIndex].transform.position, Time.deltaTime * _movementSpeed * 0.15f);
        }
    }

    public void Toggle(bool value)
    {
        _isActive = value;
        if (value)
        {
            _anim.Play("Active");
            _triggerCollider.enabled = false;
        }
        else
        {
            _anim.Play("Idle");
            _triggerCollider.enabled = true;
        }
    }

    public Transform GetAsParent()
    {
        return this.transform;
    }
}
