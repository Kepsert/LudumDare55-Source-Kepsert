using LDtkUnity;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Signpost : MonoBehaviour, ISelectable, ILDtkImportedFields
{
    [SerializeField] SpriteRenderer _feedbackArrow = null;
    [SerializeField] int _cutsceneIndex = 0;
    Cutscene _cutscene = null;

    public void OnLDtkImportFields(LDtkFields fields)
    {
        _cutsceneIndex = fields.GetInt("Index");
    }

    private void Start()
    {
        if (GameController.Instance.Mode is GameMode.Speedrun)
        {
            Destroy(this.gameObject);
        }

        _cutscene = CutscenePool.Instance.GetCutsceneByName(_cutsceneIndex);
    }

    public bool Select()
    {
        if (_cutscene != null)
        {
            CutsceneController.Instance.StartCutscene(_cutscene);
            return true;
        }
        return false;
    }

    public ISelectable Trigger()
    {
        _feedbackArrow.enabled = true;
        return this;
    }

    public ISelectable Untrigger()
    {
        _feedbackArrow.enabled = false;
        return this;
    }
}
