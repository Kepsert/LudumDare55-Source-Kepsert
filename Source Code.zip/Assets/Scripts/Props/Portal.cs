using DG.Tweening;
using Messaging;
using Messaging.Messages;
using Misc;
using Player;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Portal : MonoBehaviour, IInteractable
{
    [SerializeField] Transform _middlePoint = null;

    bool _canInteract = true;

    public bool Interact(Transform transform)
    {
        if (_canInteract)
        {
            MessageHub.Publish(new LevelEndedMessage());
            SoundController.Instance.PlaySoundByName("Finish");
            _canInteract = false;
            transform.DOMove(_middlePoint.position, 1f);
            transform.DOScale(Vector3.zero, 2.5f);
            Vector3 _rot = new Vector3(0, 0, 1800*1.5f);
            transform.DOLocalRotate(_rot, 2.5f, RotateMode.Fast).SetLoops(-1).SetEase(Ease.InCirc).SetRelative();
            Timer.Instance.AddTimer(1f, () =>
            {
                LevelController.Instance.LoadNextLevel();
            });
            return true;
        }
        return false;
    }
}
