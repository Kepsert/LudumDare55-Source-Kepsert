using LDtkUnity;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimeSpaceWall : MonoBehaviour
{
    [SerializeField] BoxCollider2D _collider = null;

}
