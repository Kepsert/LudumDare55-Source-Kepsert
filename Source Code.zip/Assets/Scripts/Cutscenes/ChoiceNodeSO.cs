using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[CreateAssetMenu(fileName = "CN_", menuName = "Dialogue System/ChoiceNode")]
public class ChoiceNodeSO : ScriptableObject
{
    [TextArea(2, 5)]
    [SerializeField] string _name;
    [TextArea(3, 10)]
    [SerializeField] string _choiceText;
    [SerializeField] DialogueNodeSO _nextNode;
    public string ChoiceText => _choiceText;
    public DialogueNodeSO NextNode => _nextNode;
}
