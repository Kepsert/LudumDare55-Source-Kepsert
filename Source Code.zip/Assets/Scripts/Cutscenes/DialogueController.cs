using Messaging;
using Messaging.Messages;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEditor.Rendering;
using UnityEngine;
using UnityEngine.UI;

public class DialogueController : MonoBehaviour, IMenuOptions
{
    public static DialogueController Instance;
    
    [SerializeField] GameObject _dialoguePanel = null;
    [SerializeField] GameObject _dialogueBoxNextArrow = null;
    [SerializeField] TMP_Text _dialogueText = null;
    [SerializeField] float _chatBeepTime = 0.4f;
    [SerializeField] GameObject _dialogueOptionsPanel = null;
    [SerializeField] List<GameObject> _dialogueOptionButtons = new List<GameObject>();

    [SerializeField] OptionSelectionHelper _dialogueOptionsHelper = null;

    float _chatBeepTimer;
    bool _typingDialogue = false;
    float _chatBeepOffset = 0;

    DialogueNodeSO _currentDialogueNode;

    bool _optionsPanelIsActive = false;

    bool _dialogueActive = false;

    private void OnEnable()
    {
        MessageHub.Subscribe<ContinueMessage>(this, ContinuePressed);
    }

    private void OnDisable()
    {
        MessageHub.Unsubscribe<ContinueMessage>(this);
    }

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            DestroyImmediate(this);
        }

        foreach (GameObject go in _dialogueOptionButtons)
        {
            go.SetActive(false);
        }
    }


    public void StartNewDialogue(Dialogue dialogue)
    {
        Debug.Log("Starting new dialogue");
        GameController.Instance.SetGameState(GameState.Dialogue);
        _currentDialogueNode = dialogue.StartingNode;
        _dialoguePanel.SetActive(true);
        _dialogueActive = true;
        ContinueDialogue();
    }

    private void ContinueDialogue()
    {
        StartCoroutine(TypeDialogue(_currentDialogueNode.DialogueText));
    }

    public void GetPlayerInput(int choiceIndex)
    {
        if (GameController.Instance.State is GameState.Cutscene || GameController.Instance.State is GameState.Dialogue)
        {
            DialogueNodeSO tempDialogueNode = _currentDialogueNode;
            DialogueNodeSO nextNode = tempDialogueNode.ChoiceNodeList[choiceIndex - 1].NextNode;

            if (nextNode != null)
            {
                _currentDialogueNode = nextNode;
                ContinueDialogue();
            }
            else
            {
                EndDialogue();
            }
            _dialogueOptionsPanel.SetActive(false);
            foreach (GameObject go in _dialogueOptionButtons)
            {
                go.SetActive(false);
            }
            _optionsPanelIsActive = false;
        }
    }

    private void EndDialogue()
    {
        _dialoguePanel.SetActive(false);
        _dialogueOptionsPanel.SetActive(false);
        _dialogueBoxNextArrow.SetActive(false);
        _dialogueActive = false;
        MessageHub.Publish(new DialogueEndedMessage());
    }

    private void ContinuePressed(ContinueMessage obj)
    {
        if (_typingDialogue)
        {
            StopAllCoroutines();
            _typingDialogue = false;
            _chatBeepTimer = 0;
            _dialogueText.text = _currentDialogueNode.DialogueText;
            if (_currentDialogueNode.HasDialogueOptions)
            {
                _dialogueOptionsPanel.SetActive(true);
                for (int i = 0; i < _currentDialogueNode.ChoiceNodeList.Count; i++)
                {
                    _dialogueOptionButtons[i].GetComponentInChildren<TMP_Text>().text = _currentDialogueNode.ChoiceNodeList[i].ChoiceText;
                }
            }
            else
            {
                _dialogueBoxNextArrow.SetActive(true);
            }
        }
        else if (!_typingDialogue && _dialogueBoxNextArrow.activeInHierarchy)
        {
            DialogueNodeSO tempDialogueNode = _currentDialogueNode;
            DialogueNodeSO nextNode = tempDialogueNode.NextNode;
            if (nextNode != null)
            {
                _currentDialogueNode = nextNode;
                ContinueDialogue();
            }
            else
            {
                EndDialogue();
            }
        }
    }

    private IEnumerator TypeDialogue(string dialogue)
    {
        _typingDialogue = true;
        if (_dialogueText != null)
        {
            _dialogueText.text = "";
        }

        string[] words = dialogue.Split(' ');

        foreach (string word in words)
        {
            float currentWidth = _dialogueText.GetPreferredValues(_dialogueText.text + " " + word).x;
            float previousWidth = _dialogueText.GetPreferredValues(_dialogueText.text).x;

            if (currentWidth > _dialogueText.rectTransform.rect.width)
            {
                _dialogueText.text += "\n";
            }
            else if (currentWidth > previousWidth && previousWidth > _dialogueText.rectTransform.rect.width)
            {
                _dialogueText.text += "\n";
            }

            foreach (var letter in word)
            {
                if (_dialogueText != null)
                {
                    _dialogueText.text += letter;
                }

                if (letter == '.' || letter == '!' || letter == '?')
                {
                    yield return new WaitForSeconds(0.1f);
                }
                else if (letter == '-' || letter == '_')
                {
                    yield return new WaitForSeconds(0.075f);
                }
                else if (letter == ',')
                {
                    yield return new WaitForSeconds(0.05f);
                }
                else
                {
                    yield return new WaitForSeconds(0.02f);
                }
            }

            _dialogueText.text += " ";
        }

        _typingDialogue = false;
    }

    private void Update()
    {
        if (_dialogueActive)
        {
            if (_typingDialogue)
            {
                if (_chatBeepTimer == 0)
                {
                    int randBeep = UnityEngine.Random.Range(0, 10);
                    if (randBeep < 6)
                    {
                        SoundController.Instance.PlaySoundByName("DialogueBeep", 1.0f);
                    }
                    else if (randBeep == 10 || randBeep == 9)
                    {
                        SoundController.Instance.PlaySoundByName("DialogueBeep", 0.90f);
                    }
                    else
                    {
                        SoundController.Instance.PlaySoundByName("DialogueBeep", 1.175f);
                    }
                    float rand = UnityEngine.Random.Range(0.1f, 0.25f);
                    _chatBeepOffset = rand;
                }

                _chatBeepTimer += Time.deltaTime;
                if (_chatBeepTimer >= _chatBeepTime - _chatBeepOffset)
                {
                    _chatBeepTimer = 0;
                }
            }

            if (!_typingDialogue && !_currentDialogueNode.HasDialogueOptions)
            {
                _dialogueBoxNextArrow.SetActive(true);
            }
            else if (!_typingDialogue && _currentDialogueNode.HasDialogueOptions)
            {
                if (!_optionsPanelIsActive)
                {
                    _dialogueOptionsPanel.SetActive(true);
                    _dialogueOptionsHelper.ActivateSelectors(_currentDialogueNode.ChoiceNodeList.Count);
                    for (int i = 0; i < _currentDialogueNode.ChoiceNodeList.Count; i++)
                    {
                        _dialogueOptionButtons[i].SetActive(true);
                        _dialogueOptionButtons[i].GetComponentInChildren<TMP_Text>().text = _currentDialogueNode.ChoiceNodeList[i].ChoiceText;
                    }
                    _optionsPanelIsActive = true;
                }
            }
            else
            {
                _dialogueBoxNextArrow.SetActive(false);
            }
        }
    }

    public void GetInput(int index, bool disableSelector = true)
    {
        if (_optionsPanelIsActive)
        {
            SoundController.Instance.PlaySoundByName("MenuSelect");
            GetPlayerInput(index);
        }
    }

    public void GetHorizontalInput(int index, int direction)
    {
        return;
    }
}
