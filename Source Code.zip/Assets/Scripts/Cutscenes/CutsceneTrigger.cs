using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CutsceneTrigger : MonoBehaviour, ITriggerable
{
    [SerializeField] Cutscene _cutscene = null;
    public Cutscene Cutscene => _cutscene;

    [SerializeField] public bool _playOnStart = false;
    [SerializeField] bool _saveHasPlayed = false;
    bool _hasPlayed = false;

    [SerializeField] GameObject _cutsceneActorsPrefab = null;

    void Awake()
    {
        Instantiate(_cutsceneActorsPrefab);
    }

    private void Start()
    {
        if (_playOnStart && GameController.Instance.Mode == GameMode.Normal)
        {
            Trigger();
        }
        else
        {
            SoundController.Instance.ChangeMusic("Game");
        }
    }

    public void Trigger()
    {
        if (_cutscene != null)
        {
            StartNewCutscene();
        }
        else
        {
            Debug.LogWarning("CUTSCENE: Trying to start cutscene but no cutscene attached");
        }
    }

    private void StartNewCutscene()
    {
        if (!_hasPlayed)
        {
            if (_saveHasPlayed)
            {
                _hasPlayed = true;
            }
            CutsceneController.Instance.StartCutscene(_cutscene);
        }
    }
}
