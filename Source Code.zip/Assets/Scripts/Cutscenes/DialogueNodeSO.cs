using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "DN_", menuName = "Dialogue System/DialogueNode")]
public class DialogueNodeSO : ScriptableObject
{
    [TextArea(2, 5)]
    [SerializeField] string _name;
    [TextArea(3, 10)]
    [SerializeField] string _dialogueText;
    [SerializeField] DialogueNodeSO _nextNode;
    [HideInInspector]
    [SerializeField] public bool HasDialogueOptions;
    [HideInInspector]
    [SerializeField] public List<ChoiceNodeSO> ChoiceNodeList = new List<ChoiceNodeSO>();
    public string DialogueText => _dialogueText;
    public DialogueNodeSO NextNode => _nextNode;
}
