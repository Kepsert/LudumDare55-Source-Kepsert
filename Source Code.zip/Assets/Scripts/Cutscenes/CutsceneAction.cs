using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[CreateAssetMenu(fileName = "CA_", menuName = "Cutscene/Cutscene Action")]
public class CutsceneAction : ScriptableObject
{
    public string _name;

    [Space(10)]
    [Header("Dialogue")]
    public bool _hasDialogue;
    [HideInInspector]
    public Dialogue _dialogue;

    [Space(10)]
    [Header("Fade")]
    public bool _fade;
    [HideInInspector]
    public string _screenToFade;
    [HideInInspector]
    public bool _fadeInScreen;
    [HideInInspector]
    public bool _fadeOutScreen;
    [HideInInspector]
    public float _fadeScreenDuration;

    [Space(10)]
    [Header("MoveTween")]
    public bool _moveTween;
    [HideInInspector]
    public string _objectToTween;
    [HideInInspector]
    public Vector3 _moveDistance;
    [HideInInspector]
    public float _moveTweenDuration;
    [HideInInspector]
    public bool _useEase;

    [Space(10)]
    [Header("Animation")]
    public bool _triggerAnimation;
    [HideInInspector]
    public string _animatorTag;
    [HideInInspector]
    public string _animationName;

    [Space(10)]
    [Header("SFX")]
    public bool _playSFX;
    [HideInInspector]
    public string _sfxName;

    [Space(10)]
    [Header("Music")]
    public bool _playMusic;
    [HideInInspector]
    public string _songName;
    [HideInInspector]
    public bool _fadeOut;
    [HideInInspector]
    public float _fadeOutDuration;

    [Space(10)]
    [Header("Toggle Game Object")]
    public bool _toggleGameObjects;
    [HideInInspector]
    public List<string> _gameObjects = new List<string>();

    [Space(10)]
    [Header("GameState")]
    public bool _changeGameState;
    [HideInInspector]
    public GameState _gameState;

    [Space(10)]
    [Header("Time")]
    public float _actionDuration;

    [Space(10)]
    [Header("LoadLevel")]
    public bool _loadLevel;
    [HideInInspector]
    public int _levelToLoad;
}
