using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CutsceneActor : MonoBehaviour, ICutsceneActor
{
    [SerializeField] string _customTag;
    public string CustomTag => _customTag;


    void Start()
    {
        if (_customTag == string.Empty)
        {
            Debug.LogWarning("CUTSCENE ACTOR: No CustomTag set up " + gameObject.name);
        }
        else
        {
            AddToActorsList();
        }
    }

    public void AddToActorsList()
    {
        CutsceneActorsController.Instance.AddCutsceneActor(this);
    }
}
