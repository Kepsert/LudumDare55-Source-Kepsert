using DG.Tweening;
using Messaging;
using Messaging.Messages;
using Misc;
using UnityEngine;
using UnityEngine.UI;

public class CutsceneController : MonoBehaviour
{
    public static CutsceneController Instance;

    Cutscene _currentCutscene;
    int _cutsceneIndex = -1;
    bool _cutsceneActive;

    float _actionTimer = 0;
    bool _waitForDialogue;

    private void OnEnable()
    {
        MessageHub.Subscribe<DialogueEndedMessage>(this, DialogueEnded);
    }

    private void OnDisable()
    {
        MessageHub.Unsubscribe<DialogueEndedMessage>(this);
    }

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            DestroyImmediate(this);
        }
    }

    private void DialogueEnded(DialogueEndedMessage obj)
    {
        _waitForDialogue = false;
    }

    public void StartCutscene(Cutscene cutscene)
    {
        _cutsceneIndex = -1;
        _actionTimer = 0;
        _currentCutscene = cutscene;
        GameController.Instance.SetGameState(GameState.Cutscene);
        InitiateNextAction();
        _cutsceneActive = true;
    }

    private void EndCutscene()
    {
        _cutsceneActive = false;
    }

    private void Update()
    {
        if (_cutsceneActive)
        {
            _actionTimer += Time.deltaTime;
            if (_actionTimer >= _currentCutscene.CutsceneActions[_cutsceneIndex]._actionDuration && !_waitForDialogue)
            {
                _actionTimer = 0;
                InitiateNextAction();
            }
        }
    }

    private void InitiateNextAction()
    {
        _cutsceneIndex++;
        Debug.Log("Cutscene index: " + _cutsceneIndex);
        if (_cutsceneIndex > _currentCutscene.CutsceneActions.Count - 1)
        {
            EndCutscene();
            return;
        }
        CutsceneAction ca = _currentCutscene.CutsceneActions[_cutsceneIndex];

        if (ca._hasDialogue)
        {
            Debug.Log("CUTSCENE: Playing Dialogue");
            _waitForDialogue = true;
            DialogueController.Instance.StartNewDialogue(ca._dialogue);
        }

        if (ca._fade)
        {
            int fadeAmount = 0;
            GameObject go = CutsceneActorsController.Instance.GetCutsceneActor(ca._screenToFade);
            if (go != null)
            {
                Image fadeImage = go.GetComponent<Image>();
                if (fadeImage != null)
                {
                    Debug.Log("CUTSCENE: Fading Screen");
                    if (ca._fadeInScreen)
                    {
                        fadeAmount = 1;
                    }
                    else if (ca._fadeOutScreen)
                    {
                        fadeAmount = 0;
                    }
                    fadeImage.DOFade(fadeAmount, ca._fadeScreenDuration);
                }
                else
                {
                    Debug.LogWarning("CUTSCENE: Trying to fade screen but image attached on " + ca.name);
                }
            }
            else
            {
                Debug.LogWarning("CUTSCENE: Trying to find fadescreen, but couldn't find one on " + ca.name);
            }
        }

        if (ca._moveTween)
        {
            GameObject go = CutsceneActorsController.Instance.GetCutsceneActor(ca._objectToTween);
            if (ca._objectToTween != null)
            {
                Transform t = go.GetComponent<Transform>();
                if (t != null)
                {
                    Debug.Log("CUTSCENE: Tweening Object");
                    Vector3 endPosition = t.position + ca._moveDistance;
                    if (ca._useEase)
                    {
                        t.DOLocalMove(endPosition, ca._moveTweenDuration).SetEase(Ease.InSine);
                    }
                    else
                    {
                        t.DOLocalMove(endPosition, ca._moveTweenDuration);
                    }
                }
                else
                {
                    Debug.LogWarning("CUTSCENE: Trying to tween an object but no Transform attached on " + ca.name);
                }
            }
            else
            {
                Debug.LogWarning("CUTSCENE: Trying to tween object but no object attached on " + ca.name);
            }
        }

        if (ca._triggerAnimation)
        {
            GameObject go = CutsceneActorsController.Instance.GetCutsceneActor(ca._animatorTag);
            if (go != null)
            {
                Animator anim;
                anim = go.GetComponent<Animator>();
                if (anim != null)
                {
                    if (anim != null)
                    {
                        Debug.Log("CUTSCENE: Playing Animation");
                        anim.Play(ca._animationName);
                    }
                }
                else
                {
                    Debug.Log("CUTSCENE: Trying to trigger animation but no animator attached");
                }
            }
            else
            {
                Debug.LogWarning("CUTSCENE: Trying to find animator gameobject, but can't find one on " + ca.name);
            }
        }

        if (ca._playSFX)
        {
            Debug.Log("CUTSCENE: Playing SFX");
            // MusicPlayer.Instance.PlaySFX(ca.sfxName);
        }

        if (ca._playMusic)
        {
            Debug.Log("CUTSCENE: Changing Music");
            if (ca._songName == string.Empty)
            {
                SoundController.Instance.StopMusic();
            }
            else
            {
                SoundController.Instance.ChangeMusic(ca._songName);
            }
        }

        if (ca._toggleGameObjects)
        {
            Debug.Log("CUTSCENE: Toggling GameObjects");
            foreach (string customTag in ca._gameObjects)
            {
                GameObject target = CutsceneActorsController.Instance.GetCutsceneActor(customTag);
                target.SetActive(!target.activeInHierarchy);
            }
        }

        if (ca._changeGameState)
        {
            Debug.Log("CUTSCENE: Changing GameState");
            Timer.Instance.AddTimer(0.1f, () =>
            {
                GameController.Instance.SetGameState(ca._gameState);
            });
        }

        if (ca._loadLevel)
        {
            LevelController.Instance.LoadNextLevel(ca._levelToLoad);
        }
    }
}
