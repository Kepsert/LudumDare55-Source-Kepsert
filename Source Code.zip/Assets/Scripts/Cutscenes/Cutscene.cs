using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "CUTSCENE_", menuName = "Cutscene/Cutscene")]
public class Cutscene : ScriptableObject
{
    [SerializeField] List<CutsceneAction> _cutsceneActions = new List<CutsceneAction>();
    public List<CutsceneAction> CutsceneActions => _cutsceneActions;
}
