using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Dialogue_", menuName = "Dialogue System/Dialogue")]
public class Dialogue : ScriptableObject
{
    [SerializeField] DialogueNodeSO _startingNode = null;
    public DialogueNodeSO StartingNode => _startingNode;
}
