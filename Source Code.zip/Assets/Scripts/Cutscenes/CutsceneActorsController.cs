using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CutsceneActorsController : MonoBehaviour
{
    public static CutsceneActorsController Instance;

    private List<CutsceneActor> _cutsceneActorsList = new List<CutsceneActor>();

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            DestroyImmediate(this);
        }
    }

    public void AddCutsceneActor(CutsceneActor cutsceneActor)
    {
        _cutsceneActorsList.Add(cutsceneActor);
    }

    public GameObject GetCutsceneActor(string customTag)
    {
        foreach (CutsceneActor actor in _cutsceneActorsList)
        {
            if (actor.CustomTag.Equals(customTag))
            {
                return (actor as MonoBehaviour).gameObject;
            }
        }
        return null;
    }
}
