using UnityEngine;

public class DialogueTrigger : MonoBehaviour, ITriggerable
{
    [SerializeField] Dialogue _dialogue = null;
    [SerializeField] bool _playOnStart = false;
    [SerializeField] bool _saveHasPlayed = false;
    bool _hasPlayed = false;

    private void Start()
    {
        if (_playOnStart)
        {
            Trigger();
        }
    }

    public void Trigger()
    {
        if (!_hasPlayed)
        {
            if (_saveHasPlayed)
            {
                _hasPlayed = true;
            }
            DialogueController.Instance.StartNewDialogue(_dialogue);
        }
    }
}
