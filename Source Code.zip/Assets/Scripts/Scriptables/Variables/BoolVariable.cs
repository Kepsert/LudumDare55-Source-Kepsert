using Messaging;
using Messaging.Messages;
using System;
using UnityEngine;

[CreateAssetMenu(menuName = "Variables/Bool", fileName = "BoolVariable", order = 6)]
public class BoolVariable : ScriptableObject
{
    public bool Value;
    public event Action<bool> _changedEvent;
    public event Action<bool> _refreshEvent;
    [HideInInspector]
    [field: SerializeField] public bool ResetOnNewLevel = false;
    [HideInInspector]
    [field: SerializeField] public bool ResetOnNewGame = false;
    [HideInInspector]
    [Space(10)]
    [field: SerializeField] public bool DefaultValue;

    [HideInInspector]
    public bool SaveBetweenSessions = false;
    [HideInInspector]
    [field: SerializeField] public bool SaveInPlayerPrefs = false;
    [HideInInspector]
    [field: SerializeField] public bool useCustomPlayerPrefsKey = false;
    [HideInInspector]
    [field: SerializeField] public string CustomPlayerPrefsKey = "Placeholder Key";

    private void OnEnable()
    {
        MessageHub.Subscribe<NewGameMessage>(this, NewGameStarted);
        MessageHub.Subscribe<LevelStartedMessage>(this, LevelStarted);
    }

    private void OnDisable()
    {
        MessageHub.Unsubscribe<NewGameMessage>(this);
        MessageHub.Unsubscribe<LevelStartedMessage>(this);
    }

    private void Awake()
    {
        if (SaveBetweenSessions)
        {
            if (PlayerPrefs.HasKey(CustomPlayerPrefsKey))
            {
                if (PlayerPrefs.GetInt(CustomPlayerPrefsKey) == -1)
                {
                    Value = false;
                }
                else if (PlayerPrefs.GetInt(CustomPlayerPrefsKey) == 1)
                {
                    Value = true;
                }
                else
                {
                    Value = DefaultValue;
                }
            }
            else
            {
                Value = DefaultValue;
            }
        }
    }

    public void Initialize()
    {
        if (SaveBetweenSessions)
        {
            if (PlayerPrefs.HasKey(CustomPlayerPrefsKey))
            {
                if (PlayerPrefs.GetInt(CustomPlayerPrefsKey) == -1)
                {
                    Value = false;
                }
                else if (PlayerPrefs.GetInt(CustomPlayerPrefsKey) == 1)
                {
                    Value = true;
                }
                else
                {
                    Value = DefaultValue;
                }
            }
        }
        else
        {
            Value = DefaultValue;
        }
    }

    private void NewGameStarted(NewGameMessage obj)
    {
        if (ResetOnNewGame)
        {
            Value = DefaultValue;
        }
    }

    private void LevelStarted(LevelStartedMessage level)
    {
        if (ResetOnNewLevel)
        {
            Value = DefaultValue;
        }
    }

    public void ChangeValue(bool value, bool notify)
    {
        Value = value;
        if (notify)
        {
            _changedEvent?.Invoke(Value);
        }
        if (SaveBetweenSessions)
        {
            PlayerPrefs.SetInt(CustomPlayerPrefsKey, (Value) ? 1 : -1);
        }
    }

    public void Refresh(bool value, bool notify)
    {
        Value = value;
        if (notify)
        {
            _refreshEvent?.Invoke(Value);
        }
    }
}
