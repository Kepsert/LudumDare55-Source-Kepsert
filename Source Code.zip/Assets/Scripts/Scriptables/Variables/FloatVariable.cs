using Messaging;
using Messaging.Messages;
using System;
using UnityEngine;

[CreateAssetMenu(menuName = "Variables/Float", fileName = "FloatVariable", order = 5)]
public class FloatVariable : ScriptableObject
{
    public float Value;
    public event Action<float> _changedEvent;
    public event Action<float> _refreshEvent;
    [HideInInspector]
    [field: SerializeField] public bool ResetOnNewLevel = false;
    [HideInInspector]
    [field: SerializeField] public bool ResetOnNewGame = false;
    [HideInInspector]
    [Space(10)]
    [field: SerializeField] public float DefaultValue;

    [HideInInspector]
    public bool SaveBetweenSessions = false;
    [HideInInspector]
    [field: SerializeField] public bool SaveInPlayerPrefs = false;
    [HideInInspector]
    [field: SerializeField] public bool useCustomPlayerPrefsKey = false;
    [HideInInspector]
    [field: SerializeField] public string CustomPlayerPrefsKey = "Placeholder Key";

    private void OnEnable()
    {
        MessageHub.Subscribe<NewGameMessage>(this, NewGameStarted);
        MessageHub.Subscribe<LevelStartedMessage>(this, LevelStarted);
    }

    private void OnDisable()
    {
        MessageHub.Unsubscribe<NewGameMessage>(this);
        MessageHub.Unsubscribe<LevelStartedMessage>(this);
    }

    public void Initialize()
    {
        if (SaveBetweenSessions)
        {
            if (PlayerPrefs.HasKey(CustomPlayerPrefsKey))
            {
                Value = PlayerPrefs.GetFloat(CustomPlayerPrefsKey);
            }
            else
            {
                Value = DefaultValue;
            }
        }
        else
        {
            Value = DefaultValue;
        }
    }

    private void Awake()
    {
        if (SaveBetweenSessions)
        {
            if (PlayerPrefs.HasKey(CustomPlayerPrefsKey))
            {
                Value = PlayerPrefs.GetFloat(CustomPlayerPrefsKey);
            }
            else
            {
                Value = DefaultValue;
            }
        }
        else
        {
            Value = DefaultValue;
        }
    }

    private void NewGameStarted(NewGameMessage obj)
    {
        if (ResetOnNewGame)
        {
            if (obj.Mode == GameMode.Normal)
            {
                Value = DefaultValue;
                PlayerPrefs.SetFloat(CustomPlayerPrefsKey, Value);
            }
        }
    }

    private void LevelStarted(LevelStartedMessage level)
    {
        if (ResetOnNewLevel)
        {
            Value = DefaultValue;
        }
    }

    public void ChangeValue(float value, bool notify)
    {
        Value = value;
        if (notify)
        {
            _changedEvent?.Invoke(Value);
        }
        if (SaveBetweenSessions)
        {
            PlayerPrefs.SetFloat(CustomPlayerPrefsKey, Value);
        }
    }

    public void Refresh(float value, bool notify)
    {
        Value = value;
        if (notify)
        {
            _refreshEvent?.Invoke(Value);
        }
    }
}
