using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TunnelTriggers : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D collision)
    {
        ITimeAffected timeAffected = collision.GetComponent<ITimeAffected>();
        if (timeAffected != null)
        {
            timeAffected.Toggle(true);
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        ITimeAffected timeAffected = collision.GetComponent<ITimeAffected>();
        if (timeAffected != null)
        {
            timeAffected.Toggle(false);
        }
    }
}
