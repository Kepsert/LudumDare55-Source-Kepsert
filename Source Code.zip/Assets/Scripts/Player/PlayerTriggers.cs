using Messaging;
using Messaging.Messages;
using Player;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerTriggers : MonoBehaviour
{
    [SerializeField] PlayerController _playerController = null;
    [SerializeField] TunnelScreenWrap _tunnelScreenWrap = null;

    List<ICollectible> _collectibleList = new List<ICollectible>();
    ISelectable _selectable;

    private Transform _originalParent;

    private void OnEnable()
    {
        if (_playerController == null)
        {
            _playerController = GetComponent<PlayerController>();
        }
        if (_tunnelScreenWrap == null)
        {
            _tunnelScreenWrap= GetComponent<TunnelScreenWrap>();
        }

        MessageHub.Subscribe<UpPressedMessage>(this, UpPressed);

        _playerController.Specialed += Specialed;
        MessageHub.Subscribe<DialogueEndedMessage>(this, DialogueEnded);

        _originalParent = this.transform;
    }

    private void OnDisable()
    {
        _playerController.Specialed += Specialed;
        MessageHub.Unsubscribe<UpPressedMessage>(this);
        MessageHub.Unsubscribe<DialogueEndedMessage>(this);
    }

    private void DialogueEnded(DialogueEndedMessage obj)
    {
        _playerController.ReturnControl();
    }

    private void UpPressed(UpPressedMessage obj)
    {
        Debug.Log(_selectable);
        if (GameController.Instance.State != GameState.Dialogue)
        {
            Debug.Log("Up Pressed");
            if (_selectable != null)
            {
                if (_selectable.Select())
                {
                    _playerController.TakeAwayControl();
                }
            }
        }
    }

    private void Update()
    {
        if (_tunnelScreenWrap.TunnelActive())
        {
            this.transform.SetParent(_originalParent);
        }
    }

    private void Specialed(Vector2 arg1, bool arg2)
    {
        if (_tunnelScreenWrap.TunnelActive())
        {
            _collectibleList[0].Reset();
            _collectibleList.RemoveAt(0);
        }
        this.transform.SetParent(_originalParent);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        ICollectible collectible = collision.GetComponent<ICollectible>();
        if (collectible != null)
        {
            //if (!_tunnelScreenWrap.TunnelActive())
            //{
                ICollectible collectedObject = collectible.Collect();
                if (collectedObject != null)
                {
                    SoundController.Instance.PlaySoundByName("Energy");
                    _collectibleList.Add(collectedObject);
                }
            //}
        }

        IInteractable interactable = collision.GetComponent<IInteractable>();
        if (interactable != null)
        {
            if (interactable.Interact(this.transform))
            {
                _tunnelScreenWrap.DisableClock();
                _playerController.TakeAwayControl();
            }
        }

        ISelectable selectable = collision.GetComponent<ISelectable>();
        if (selectable != null)
        {
             _selectable = selectable.Trigger();
        }

        IKiller killer = collision.GetComponent<IKiller>();
        if (killer != null)
        {
            if (killer.ActiveKiller())
            {
                _playerController.Death();
            }
        }

        IParentable parentable = collision.GetComponent<IParentable>();
        if (parentable != null)
        {
            if (!_tunnelScreenWrap.TunnelActive())
            {

            }
                //this.transform.SetParent(parentable.GetAsParent());
            else
                this.transform.SetParent(_originalParent);
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        ISelectable selectable = collision.GetComponent<ISelectable>();
        if (selectable != null)
        {
            selectable.Untrigger();
            _selectable = null;
        }

        IParentable parentable = collision.GetComponent<IParentable>();
        if (parentable != null)
        {
            this.transform.SetParent(_originalParent);
        }
    }
}
