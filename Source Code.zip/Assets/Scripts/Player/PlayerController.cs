using Messaging;
using Messaging.Messages;
using Misc;
using System;
using UnityEngine;

// Player Controller inspired and based on the Player Controller by Tarodev

namespace Player
{
    [RequireComponent(typeof(Rigidbody2D), typeof(CapsuleCollider2D))]
    public class PlayerController : MonoBehaviour, IPlayerController
    {
        [SerializeField] private ScriptableStats _stats = null;
        [SerializeField] PlayerAnimator _playerAnimator = null;
        [SerializeField] SpriteRenderer _spriteRenderer = null;

        #region Internal

        [HideInInspector] private Rigidbody2D _rigidbody = null;
        [SerializeField] private CapsuleCollider2D _standingCollider = null;
        [SerializeField] private CapsuleCollider2D _crouchingCollider = null;
        [SerializeField] private PlayerCrushPoint _playerCrushPoint = null;
        private CapsuleCollider2D _collider; // Currently active collider
        private PlayerInput _input;
        private bool _cachedTriggerSetting;

        protected FrameInput FrameInput;
        private Vector2 _speed;
        private Vector2 _currentExternalVelocity;
        private int _fixedFrame;
        private bool _hasControl = true;

        private float _originalFallingSpeed;
        private float _modifiedFallingSpeed;

        [SerializeField] FloatVariable _summoningEnergyVariable = null;

        bool _phasingOut = false;
        float _phaseOutDuration = .3f;
        Guid _phaseOutTimer;
        bool _phasingIn = false;
        float _phaseInDuration = .3f;
        Guid _phaseInTimer;

        #endregion

        #region External

        public event Action<bool, float> GroundedChanged;
        public event Action<bool, Vector2> DashingChanged;
        public event Action<bool> WallGrabChanged;
        public event Action<bool> LedgeClimbChanged;
        public event Action<bool> Jumped;
        public event Action AirJumped;
        public event Action Attacked;
        public event Action<Vector2, bool> Specialed;
        public event Action<bool> Slided;

        public ScriptableStats PlayerStats => _stats;
        public Vector2 Input => FrameInput.Move;
        public Vector2 Speed => _speed;
        public Vector2 Velocity => _rigidbody.velocity;
        public Vector2 GroundNormal { get; private set; }
        public int WallDirection { get; private set; }
        public bool Crouching { get; private set; }
        public bool ClimbingLadder { get; private set; }
        public bool GrabbingLedge { get; private set; }
        public bool ClimbingLedge { get; private set; }
        public bool Sliding { get; private set; }

        private LayerMask _originalPlayerMask;
        private LayerMask _modifiedPlayerMask;

        public bool Special { get; private set; }

        private TunnelScreenWrap _tunnelScreenWrap;

        public virtual void ApplyVelocity(Vector2 vel, PlayerForce forceType)
        {
            if (forceType == PlayerForce.Burst) _speed += vel;
            else _currentExternalVelocity += vel;
        }

        public virtual void SetVelocity(Vector2 vel, PlayerForce velocityType)
        {
            if (velocityType == PlayerForce.Burst) _speed = vel;
            else _currentExternalVelocity = vel;
        }

        public virtual void TakeAwayControl(bool resetVelocity = true)
        {
            if (resetVelocity) _rigidbody.velocity = Vector2.zero;
            _hasControl = false;
        }

        public virtual void ReturnControl()
        {
            _speed = Vector2.zero;
            _hasControl = true;
        }

        #endregion

        protected virtual void Awake()
        {
            if (_rigidbody == null) _rigidbody = GetComponent<Rigidbody2D>();
            if (_input == null) _input = GetComponent<PlayerInput>();
            if (_playerAnimator == null) _playerAnimator = GetComponent<PlayerAnimator>();
            if (_spriteRenderer == null) Debug.Log("Give up on life");
            _cachedTriggerSetting = Physics2D.queriesHitTriggers;
            Physics2D.queriesStartInColliders = false;
            if (_tunnelScreenWrap == null) _tunnelScreenWrap = GetComponent<TunnelScreenWrap>();

            ToggleColliders(isStanding: true);

            _originalPlayerMask = _stats.PlayerLayer;
            int layerIndex = LayerMask.NameToLayer("Ground");
            int layerMask = 1 << layerIndex;
            _modifiedPlayerMask = _originalPlayerMask | layerMask;

            _originalFallingSpeed = _stats.MaxFallSpeed;
            _modifiedFallingSpeed = _originalFallingSpeed * 0.35f;
        }

        protected virtual void Update()
        {
            GatherInput();
        }

        void OnEnable()
        {
            MessageHub.Subscribe<RestartPressedMessage>(this, LevelRestart);
            MessageHub.Subscribe<SkipPressedMessage>(this, SkipLevel);
        }

        void OnDisable()
        {
            MessageHub.Unsubscribe<RestartPressedMessage>(this);
            MessageHub.Unsubscribe<SkipPressedMessage>(this);
        }

        private void LevelRestart(RestartPressedMessage obj)
        {
            Death();
        }

        private void SkipLevel(SkipPressedMessage obj)
        {
            TakeAwayControl();
            _rigidbody.isKinematic = true;
            LevelController.Instance.LoadNextLevel();
        }

        protected virtual void GatherInput()
        {
            if (GameController.Instance.State is not GameState.Cutscene && GameController.Instance.State is not GameState.Dialogue)
            {
                FrameInput = _input.FrameInput;

                if (_stats.SnapInput)
                {
                    FrameInput.Move.x = Mathf.Abs(FrameInput.Move.x) < _stats.HorizontalDeadzoneTreshold ? 0 : Mathf.Sign(FrameInput.Move.x);
                    FrameInput.Move.y = Mathf.Abs(FrameInput.Move.y) < _stats.VerticalDeadzoneTreshold ? 0 : Mathf.Sign(FrameInput.Move.y);
                }

                if (FrameInput.JumpDown)
                {
                    _jumpToConsume = true;
                    _frameJumpWasPressed = _fixedFrame;
                }

                if (FrameInput.Move.x != 0) _stickyFeet = false;

                if (FrameInput.DashDown && _stats.AllowDash) _dashToConsume = true;
                if (FrameInput.AttackDown && _stats.AllowAttacks) _attackToConsume = true;
                if (FrameInput.SpecialDown && _stats.AllowSpecial) _specialToConsume = true;
            }
        }

        protected virtual void FixedUpdate()
        {
            _fixedFrame++;

            CheckCollisions();
            HandleCollisions();
            HandleWalls();
            HandleLedges();
            HandleLadders();

            HandleCrouching();
            HandleJump();
            HandleDash();
            HandleSlide();
            HandleAttacking();
            HandleSpecial();

            HandleHorizontal();
            HandleVertical();
            ApplyMovement();

            HandleCameraCalls();

            HandleAnimations();

            _tunnelScreenWrap.Wrap(this.gameObject);
        }

        #region Collisions

        private readonly RaycastHit2D[] _groundHits = new RaycastHit2D[2];
        private readonly RaycastHit2D[] _ceilingHits = new RaycastHit2D[2];
        private readonly Collider2D[] _wallHits = new Collider2D[2];
        private readonly Collider2D[] _ladderHits = new Collider2D[2];
        private RaycastHit2D _hittingWall;
        private int _groundHitCount;
        private int _ceilingHitCount;
        private int _wallHitCount;
        private int _ladderHitCount;
        private int _frameLeftGrounded = int.MinValue;
        private bool _grounded;
        private Vector2 _skinWidth = new Vector2(0.02f, 0.02f);

        protected virtual void CheckCollisions()
        {
            Physics2D.queriesHitTriggers = false;

            if (_tunnelScreenWrap.TunnelActive())
            {
                _groundHitCount = Physics2D.CapsuleCastNonAlloc(_collider.bounds.center, _collider.size, _collider.direction, 0, Vector2.down, _groundHits, _stats.GrounderDistance, ~_modifiedPlayerMask);
                _ceilingHitCount = Physics2D.CapsuleCastNonAlloc(_collider.bounds.center, _collider.size, _collider.direction, 0, Vector2.up, _ceilingHits, _stats.GrounderDistance, ~_modifiedPlayerMask);
            }
            else
            {
                // Ground and ceiling
                _groundHitCount = Physics2D.CapsuleCastNonAlloc(_collider.bounds.center, _collider.size, _collider.direction, 0, Vector2.down, _groundHits, _stats.GrounderDistance, ~_stats.PlayerLayer);
                _ceilingHitCount = Physics2D.CapsuleCastNonAlloc(_collider.bounds.center, _collider.size, _collider.direction, 0, Vector2.up, _ceilingHits, _stats.GrounderDistance, ~_stats.PlayerLayer);
            }

            // Walls and Ladders
            var bounds = GetWallDetectionBounds();
            _wallHitCount = Physics2D.OverlapBoxNonAlloc(bounds.center, bounds.size, 0, _wallHits, _stats.ClimbableLayer);

            _hittingWall = Physics2D.CapsuleCast(_collider.bounds.center, _collider.size, _collider.direction, 0, new Vector2(_input.FrameInput.Move.x, 0), _stats.GrounderDistance, ~_stats.PlayerLayer);

            Physics2D.queriesHitTriggers = true;
            _ladderHitCount = Physics2D.OverlapBoxNonAlloc(bounds.center, bounds.size, 0, _ladderHits, _stats.LadderLayer);
            Physics2D.queriesHitTriggers = _cachedTriggerSetting;
        }

        protected virtual bool TryGetGroundNormal(out Vector2 groundNormal)
        {
            Physics2D.queriesHitTriggers = false;
            var hit = Physics2D.Raycast(_rigidbody.position, Vector2.down, _stats.GrounderDistance * 2, ~_stats.PlayerLayer);
            Physics2D.queriesHitTriggers = _cachedTriggerSetting;
            groundNormal = hit.normal;
            return hit.collider;
        }

        protected virtual Bounds GetWallDetectionBounds()
        {
            var colliderOrigin = _rigidbody.position + _standingCollider.offset;
            return new Bounds(colliderOrigin, _stats.WallDetectorSize);
        }

        protected virtual void HandleCollisions()
        {
            // Hit a ceiling
            if (_ceilingHitCount > 0)
            {
                // Prevent sticking after an inair jump
                _currentExternalVelocity.y = Mathf.Min(0f, _currentExternalVelocity.y);
                _speed.y = Mathf.Min(0, _speed.y);
            }

            // Landed on the ground
            if (!_grounded && _groundHitCount > 0)
            {
                _grounded = true;
                ResetDash();
                ResetJump();
                GroundedChanged?.Invoke(true, Mathf.Abs(_speed.y));
                if (FrameInput.Move.x == 0) _stickyFeet = true;
            }
            // Left the ground
            else if (_grounded && _groundHitCount == 0)
            {
                _grounded = false;
                _frameLeftGrounded = _fixedFrame;
                GroundedChanged?.Invoke(false, 0);
            }
        }

        protected virtual bool IsStandingPosClear(Vector2 pos) => CheckPos(pos, _standingCollider);
        protected virtual bool IsCrouchingPosClear(Vector2 pos) => CheckPos(pos, _crouchingCollider);

        private bool CheckPos(Vector2 pos, CapsuleCollider2D col)
        {
            Physics2D.queriesHitTriggers = false;
            var hit = Physics2D.OverlapCapsule(pos + col.offset, col.size - _skinWidth, col.direction, 0, ~_stats.PlayerLayer);
            Physics2D.queriesHitTriggers = _cachedTriggerSetting;
            return !hit;
        }

        #endregion

        #region Walls

        private readonly ContactPoint2D[] _wallContacts = new ContactPoint2D[2];
        private float _currentWallJumpMoveMultiplier = 1f; // Horizontal input influence
        private int _lastWallDirection; // for coyote time
        private int _frameLeftWall; // for coyote wall jumps
        private bool _isLeavingWall; // prevents re-sticking to wall
        private bool _isOnWall;

        protected virtual void HandleWalls()
        {
            if (!_stats.AllowWalls) return;

            _currentWallJumpMoveMultiplier = Mathf.MoveTowards(_currentWallJumpMoveMultiplier, 1f, 1f / _stats.WallJumpInputLossFrames);

            // Prioritize nearest wall?
            if (_wallHitCount > 0 && _wallHits[0].GetContacts(_wallContacts) > 0)
            {
                WallDirection = (int)Mathf.Sign(_wallContacts[0].point.x - transform.position.x);
                _lastWallDirection = WallDirection;
            }
            else
            {
                WallDirection = 0;
            }

            if (!_isOnWall && ShouldStickToWall() && _speed.y <= 0) ToggleOnWall(true);
            else if (_isOnWall && !ShouldStickToWall()) ToggleOnWall(false);

            bool ShouldStickToWall()
            {
                if (WallDirection == 0 || _grounded) return false;
                return !_stats.RequireInputPush || (HorizontalInputPressed && Mathf.Sign(FrameInput.Move.x) == WallDirection);
            }
        }

        private void ToggleOnWall(bool on)
        {
            _isOnWall = on;
            if (on)
            {
                _speed = Vector2.zero;
                _currentExternalVelocity = Vector2.zero;
                _bufferedJumpUsable = true;
                _wallJumpCoyoteUsable = true;
            }
            else
            {
                _frameLeftWall = _fixedFrame;
                _isLeavingWall = false;
                ResetAirJumps();
            }

            WallGrabChanged?.Invoke(on);
        }

        #endregion

        #region Ledges

        private Vector2 _ledgeCornerPos;
        private bool _climbIntoCrawl;

        protected virtual bool LedgeClimbInputDetected => Input.y > _stats.VerticalDeadzoneTreshold || Input.x == WallDirection;

        protected virtual void HandleLedges()
        {
            if (!_stats.AllowLedges) return;
            if (ClimbingLedge || !_isOnWall) return;

            GrabbingLedge = TryGetLedgeCorner(out _ledgeCornerPos);

            if (GrabbingLedge) HandleLedgeGrabbing();
        }

        protected virtual bool TryGetLedgeCorner(out Vector2 cornerPos)
        {
            cornerPos = Vector2.zero;
            var grabHeight = _rigidbody.position + _stats.LedgeGrabPoint.y * Vector2.up;

            var hit1 = Physics2D.Raycast(grabHeight + _stats.LedgeRaycastSpacing * Vector2.down, WallDirection * Vector2.right, 0.5f, _stats.ClimbableLayer);
            if (!hit1.collider) return false; // Should hit below ledge. Used to determine xPos accurately.

            var hit2 = Physics2D.Raycast(grabHeight + _stats.LedgeRaycastSpacing * Vector2.up, WallDirection * Vector2.right, 0.5f, _stats.ClimbableLayer);
            if (hit2.collider) return false; // We only are within ledge-grab range when the first hits and the second doesn't

            var hit3 = Physics2D.Raycast(grabHeight + new Vector2(WallDirection * 0.5f, _stats.LedgeRaycastSpacing), Vector2.down, 0.5f, _stats.ClimbableLayer);
            if (!hit3.collider) return false; // Gets out yPos of the corner

            cornerPos = new(hit1.point.x, hit3.point.y);
            return true;
        }

        protected virtual void HandleLedgeGrabbing()
        {
            // Nudge towards better grabbing position
            if (Input.x == 0 && _hasControl)
            {
                var pos = _rigidbody.position;
                var targetPos = _ledgeCornerPos - Vector2.Scale(_stats.LedgeGrabPoint, new(WallDirection, 1f));
                _rigidbody.position = Vector2.MoveTowards(pos, targetPos, _stats.LedgeGrabDeceleration * Time.fixedDeltaTime);
            }

            if (LedgeClimbInputDetected)
            {
                var finalPos = _ledgeCornerPos + Vector2.Scale(_stats.StandUpOffset, new(WallDirection, 1f));

                if (IsStandingPosClear(finalPos))
                {
                    _climbIntoCrawl = false;
                    StartLedgeClimb();
                }
                else if (_stats.AllowCrouching && IsCrouchingPosClear(finalPos))
                {
                    _climbIntoCrawl = true;
                    StartLedgeClimb(intoCrawl: true);
                }
            }
        }

        protected virtual void StartLedgeClimb(bool intoCrawl = false)
        {
            LedgeClimbChanged?.Invoke(intoCrawl);
            TakeAwayControl();
            ClimbingLedge = true;
            GrabbingLedge = false;
            _rigidbody.position = _ledgeCornerPos - Vector2.Scale(_stats.LedgeGrabPoint, new(WallDirection, 1f));
        }

        public virtual void TeleportMidLedgeClimb()
        {
            transform.position = _rigidbody.position = _ledgeCornerPos + Vector2.Scale(_stats.StandUpOffset, new(WallDirection, 1f));
            if (_climbIntoCrawl) TryToggleCrouching(shouldCrouch: true);
            ToggleOnWall(false);
        }

        public virtual void FinishClimbingLedge()
        {
            ClimbingLedge = false;
            ReturnControl();
        }

        #endregion

        #region Ladders

        private Vector2 _ladderSnapVel;
        private int _frameLeftLadder;

        protected virtual bool CanEnterLadder => _ladderHitCount > 0 && _fixedFrame > _frameLeftLadder + _stats.LadderCooldownFrames;
        protected virtual bool ShouldMountLadder => _stats.AutoAttachToLadders || FrameInput.Move.y > _stats.VerticalDeadzoneTreshold || (!_grounded && FrameInput.Move.y < -_stats.VerticalDeadzoneTreshold);
        protected virtual bool ShouldDismountLadder => !_stats.AutoAttachToLadders && _grounded && FrameInput.Move.y < -_stats.VerticalDeadzoneTreshold;
        protected virtual bool ShouldCenterOnLadder => _stats.SnapToLadders && FrameInput.Move.x == 0 && _hasControl;

        protected virtual void HandleLadders()
        {
            if (!_stats.AllowLadders) return;

            if (!ClimbingLadder && CanEnterLadder && ShouldMountLadder) ToggleClimbingLadder(true);
            else if (ClimbingLadder && (_ladderHitCount == 0 || ShouldDismountLadder)) ToggleClimbingLadder(false);

            if (ClimbingLadder && ShouldCenterOnLadder)
            {
                var pos = _rigidbody.position;
                var targetX = _ladderHits[0].transform.position.x;
                _rigidbody.position = Vector2.SmoothDamp(pos, new Vector2(targetX, pos.y), ref _ladderSnapVel, _stats.LadderSnapTime);
            }
        }

        private void ToggleClimbingLadder(bool on)
        {
            if (ClimbingLadder == on) return;
            if (on)
            {
                _speed = Vector2.zero;
                _ladderSnapVel = Vector2.zero; // Reset damping velocity for consistency
            }
            else
            {
                if (_ladderHitCount > 0) _frameLeftLadder = _fixedFrame; // Prevent immediately re-mounting the ladder
                if (FrameInput.Move.y > 0) _speed.y += _stats.LadderPopForce; // Pop off the ladder
            }

            ClimbingLadder = on;
            ResetAirJumps();
        }

        #endregion

        #region Crouching

        private int _frameStartedCrouching;

        protected virtual bool CrouchPressed => FrameInput.Move.y < -_stats.VerticalDeadzoneTreshold;
        protected virtual bool CanStand => IsStandingPosClear(_rigidbody.position + new Vector2(0, _stats.CrouchBufferCheck));

        protected virtual void HandleCrouching()
        {
            if (!_stats.AllowCrouching) return;

            if (!Crouching && CrouchPressed && _grounded) TryToggleCrouching(true);
            else if (Crouching && (!CrouchPressed || !_grounded)) TryToggleCrouching(false);
        }

        protected virtual bool TryToggleCrouching(bool shouldCrouch)
        {
            Debug.Log("Trying to get up. CanStand? " + CanStand);
            if (Crouching && !CanStand) return false;

            Crouching = shouldCrouch;
            ToggleColliders(!shouldCrouch);
            if (Crouching) _frameStartedCrouching = _fixedFrame;
            return true;
        }

        protected virtual void ToggleColliders(bool isStanding)
        {
            _collider = isStanding ? _standingCollider : _crouchingCollider;
            _standingCollider.enabled = isStanding;
            _crouchingCollider.enabled = !isStanding;
        }

        #endregion

        #region Jumping

        private bool _jumpToConsume;
        private bool _bufferedJumpUsable;
        private bool _endedJumpEarly;
        private bool _coyoteUsable;
        private bool _wallJumpCoyoteUsable;
        private int _frameJumpWasPressed;
        private int _airJumpsRemaining;

        protected virtual bool HasBufferedJump => _bufferedJumpUsable && _fixedFrame < _frameJumpWasPressed + _stats.JumpBufferFrames && !Crouching && _fixedFrame > 10;
        protected virtual bool CanUseCoyote => _coyoteUsable && !_grounded && _fixedFrame < _frameLeftGrounded + _stats.CoyoteFrames;
        protected virtual bool CanWallJump => (_isOnWall && !_isLeavingWall) || (_wallJumpCoyoteUsable && _fixedFrame < _frameLeftWall + _stats.WallJumpCoyoteFrames);
        protected virtual bool CanAirJump => !_grounded && _airJumpsRemaining > 0;

        protected virtual void HandleJump()
        {
            if (Crouching)
            {
                _jumpToConsume = false;
                return;
            }

            if (!_endedJumpEarly && !_grounded && !FrameInput.JumpHeld && _rigidbody.velocity.y > 0) _endedJumpEarly = true; // Early end detection
            if (!_jumpToConsume && !HasBufferedJump) return;

            if (CanWallJump) WallJump();
            else if (_grounded || ClimbingLadder || CanUseCoyote) NormalJump();
            else if (_jumpToConsume && CanAirJump) AirJump();

            _jumpToConsume = false;
        }

        protected virtual void NormalJump()
        {
            if (Crouching && !TryToggleCrouching(false)) return;
            _endedJumpEarly = false;
            _frameJumpWasPressed = 0; // To prevent double dipping input jumptoconsume and bufferedjump for low ceilings
            _bufferedJumpUsable = false;
            _coyoteUsable = false;
            ToggleClimbingLadder(false);
            _speed.y = _stats.JumpPower;
            Jumped?.Invoke(false);
            SoundController.Instance.PlaySoundByName("Jump");
        }

        protected virtual void WallJump()
        {
            _endedJumpEarly = false;
            _bufferedJumpUsable = false;
            if (_isOnWall) _isLeavingWall = true; // Only toggle if it's a real walljump, not a coyote one
            _wallJumpCoyoteUsable = false;
            _currentWallJumpMoveMultiplier = 0;
            _speed = Vector2.Scale(_stats.WallJumpPower, new(-_lastWallDirection, 1));
            Jumped?.Invoke(true);
        }

        private void AirJump()
        {
            _endedJumpEarly = false;
            _airJumpsRemaining--;
            _speed.y = _stats.JumpPower * (_stats.AirJumpPenalty ? (1 - _stats.AirJumpforcePenalty) : 1);
            _currentExternalVelocity.y = 0;
            AirJumped?.Invoke();
        }

        protected virtual void ResetJump()
        {
            _coyoteUsable = true;
            _bufferedJumpUsable = true;
            _endedJumpEarly = false;
            ResetAirJumps();
        }

        protected virtual void ResetAirJumps() => _airJumpsRemaining = _stats.MaxAirJumps;

        #endregion

        #region Dashing

        private bool _dashToConsume;
        private bool _canDash;
        private Vector2 _dashVel;
        private bool _dashing;
        private int _startedDashing;
        private float _nextDashTime;

        protected virtual void HandleDash()
        {
            if (_dashToConsume && _canDash && !Crouching && Time.time > _nextDashTime)
            {
                var dir = new Vector2(FrameInput.Move.x, Mathf.Max(FrameInput.Move.y, 0f)).normalized;
                if (dir == Vector2.zero)
                {
                    _dashToConsume = false;
                    return;
                }

                _dashVel = dir * _stats.DashVelocity;
                _dashing = true;
                _canDash = false;
                _startedDashing = _fixedFrame;
                _nextDashTime = Time.time + _stats.DashCooldown;
                DashingChanged?.Invoke(true, dir);

                _currentExternalVelocity = Vector2.zero; // Strip external buildup
            }

            if (_dashing)
            {
                _speed = _dashVel;
                // Cancel when time is out or we've reached our max safety distance
                if (_fixedFrame > _startedDashing + _stats.DashDurationFrames)
                {
                    _dashing = false;
                    DashingChanged?.Invoke(false, Vector2.zero);
                    _speed.y = Mathf.Min(0, _speed.y);
                    _speed.x *= _stats.DashEndHorizontalMultiplier;
                    if (_grounded) ResetDash();
                }
            }

            _dashToConsume = false;
        }

        protected virtual void ResetDash()
        {
            _canDash = true;
        }

        #endregion

        #region Attacking

        private bool _attackToConsume;
        private int _frameLastAttacked = int.MinValue;

        protected virtual void HandleAttacking()
        {
            if (!_attackToConsume) return;
            // Animations might be weird if attacking while crouching; use seperate animation of not allow it while crouching
            if (_fixedFrame > _frameLastAttacked + _stats.AttackFrameCooldown)
            {
                _frameLastAttacked = _fixedFrame;
                Attacked?.Invoke();
            }

            _attackToConsume = false;
        }

        #endregion

        #region Sliding

        private bool _sliding;

        private void HandleSlide()
        {
            //throw new NotImplementedException();
        }

        #endregion

        #region Special

        private bool _specialToConsume;
        private int _frameLastSpecialed = int.MinValue;

        protected virtual void HandleSpecial()
        {
            if (!_specialToConsume) return;

            if (!_tunnelScreenWrap.TunnelActive())
            {
                if (_fixedFrame > _frameLastSpecialed + _stats.SpecialFrameCooldown && _summoningEnergyVariable.Value > 0)
                {
                    _phasingIn = false;
                    Timer.Instance.RemoveTimer(_phaseInTimer);

                    _playerAnimator.PlayAnim("PhaseOut");
                    _phasingOut = true;
                    _phaseOutTimer = Timer.Instance.AddTimer(_phaseOutDuration, () =>
                    {
                        _phasingOut = false;
                    });

                    _playerCrushPoint.Toggle(false);

                    _frameLastSpecialed = _fixedFrame;
                    if (FrameInput.Move.y > 0.5f || FrameInput.Move.y < -0.5f)
                    {
                        Specialed?.Invoke(this.transform.position, false);
                    }
                    else
                    {
                        Specialed?.Invoke(this.transform.position, true);
                    }
                    _summoningEnergyVariable.ChangeValue(_summoningEnergyVariable.Value - 1, true);
                }
            }
            else
            {
                if (_fixedFrame > _frameLastSpecialed + _stats.SpecialFrameCooldown)
                {
                    _phasingOut = false;
                    Timer.Instance.RemoveTimer(_phaseOutTimer);

                    _playerAnimator.PlayAnim("PhaseIn");
                    _phasingIn = true;
                    _phaseInTimer = Timer.Instance.AddTimer(_phaseInDuration, () =>
                    {
                        _phasingIn = false;
                    });

                    _playerCrushPoint.Toggle(true);

                    _frameLastSpecialed = _fixedFrame;
                    if (FrameInput.Move.y > 0.5f || FrameInput.Move.y < -0.5f)
                    {
                        Specialed?.Invoke(this.transform.position, false);
                    }
                    else
                    {
                        Specialed?.Invoke(this.transform.position, true);
                    }
                }
            }

            _specialToConsume = false;
        }

        #endregion

        #region Horizontal

        protected virtual bool HorizontalInputPressed => Mathf.Abs(FrameInput.Move.x) > _stats.HorizontalDeadzoneTreshold;

        private bool _stickyFeet;


        protected virtual void HandleHorizontal()
        {
            if (_dashing) return;
            if (_sliding) return;

            // Deceleration
            if (!HorizontalInputPressed)
            {
                var deceleration = _grounded ? _stats.GroundDeceleration * (_stickyFeet ? _stats.StickyFeetMultiplier : 1) : _stats.AirDeceleration;
                _speed.x = Mathf.MoveTowards(_speed.x, 0, deceleration * Time.fixedDeltaTime);
            }
            // Crawling
            else if (Crouching && _grounded)
            {
                var crouchPoint = Mathf.InverseLerp(0, _stats.CrouchSlowdownFrames, _fixedFrame - _frameStartedCrouching);
                var diminishedMaxSpeed = _stats.MaxSpeed * Mathf.Lerp(1, _stats.CrouchSpeedPenalty, crouchPoint);
                _speed.x = Mathf.MoveTowards(_speed.x, FrameInput.Move.x * diminishedMaxSpeed, _stats.GroundDeceleration * Time.fixedDeltaTime);
            }
            // Regular horizontal movement
            else
            {
                // Prevent useless horizontal speed buildup when against a wall
                if (_hittingWall.collider && Mathf.Abs(_rigidbody.velocity.x) < 0.01f && !_isLeavingWall) _speed.x = 0;



                var xInput = FrameInput.Move.x * (ClimbingLadder ? _stats.LadderShimmySpeedMultiplier : 1);
                _speed.x = Mathf.MoveTowards(_speed.x, xInput * _stats.MaxSpeed, _currentWallJumpMoveMultiplier * _stats.Acceleration * Time.fixedDeltaTime);
            }
        }

        #endregion

        #region Vertical

        protected virtual void HandleVertical()
        {
            if (_dashing) return;

            // Ladders
            if (ClimbingLadder)
            {
                var yInput = FrameInput.Move.y;
                _speed.y = yInput * (yInput > 0 ? _stats.LadderClimbSpeed : _stats.LadderSlideSpeed);
            }
            // Grounded && Slopes
            else if (_grounded && _speed.y <= 0f)
            {
                _speed.y = _stats.GroundingForce;

                if (TryGetGroundNormal(out var groundNormal))
                {
                    GroundNormal = groundNormal;
                    if (!Mathf.Approximately(GroundNormal.y, 1f))
                    {
                        // on a slape
                        _speed.y = _speed.x * -GroundNormal.x / GroundNormal.y;
                        if (_speed.x != 0) _speed.y += _stats.GroundingForce;
                    }
                }
            }
            // Wall Climbing / Sliding
            else if (_isOnWall && !_isLeavingWall)
            {
                if (FrameInput.Move.y > 0f) _speed.y = _stats.WallClimbSpeed;
                else if (FrameInput.Move.y < 0) _speed.y = -_stats.MaxWallFallSpeed;
                else if (GrabbingLedge) _speed.y = Mathf.MoveTowards(_speed.y, 0, _stats.LedgeGrabDeceleration * Time.fixedDeltaTime);
                else _speed.y = Mathf.MoveTowards(Mathf.Min(_speed.y, 0), -_stats.MaxWallFallSpeed, _stats.WallFallAcceleration * Time.fixedDeltaTime);
            }
            // In air
            else
            {
                var inAirGravity = _stats.FallAcceleration;
                if (_endedJumpEarly && _speed.y > 0) inAirGravity *= _stats.JumpEndEarlyGravityModifier;

                if (_tunnelScreenWrap.TunnelActive())
                {
                    _speed.y = Mathf.MoveTowards(_speed.y, -_modifiedFallingSpeed, inAirGravity * Time.fixedDeltaTime);
                }
                else
                {
                    _speed.y = Mathf.MoveTowards(_speed.y, -_originalFallingSpeed, inAirGravity * Time.fixedDeltaTime);
                }


            }
        }

        #endregion

        #region Animations

        const float _dustStepAnimDuration = .4f;
        float _dustStepAnimTimer = 0;

        [SerializeField] Transform _dustSpawnLeft = null;
        [SerializeField] Transform _dustSpawnRight = null;

        private void HandleAnimations()
        {
            if (!_playerDying)
            {
                if (FrameInput.Move.x > 0)
                {
                    _spriteRenderer.flipX = false;
                }
                else if (FrameInput.Move.x < 0)
                {
                    _spriteRenderer.flipX = true;
                }

                if (_grounded)
                {
                    if ((_rigidbody.velocity.x < 1f && _rigidbody.velocity.x > -1f) && _rigidbody.velocity.y < 1f)
                    {
                        if (FrameInput.Move == Vector2.zero)
                        {
                            if (!_tunnelScreenWrap.TunnelActive())
                            {
                                if (!_phasingIn)
                                {
                                    _playerAnimator.PlayAnim("Idle");
                                    _dustStepAnimTimer = 0;
                                }
                            }
                            else
                            {
                                if (!_phasingOut)
                                {
                                    _playerAnimator.PlayAnim("TunnelIdle");
                                    _dustStepAnimTimer = 0;
                                }
                            }
                        }
                    }
                    else if ((_rigidbody.velocity.x > 1f || _rigidbody.velocity.x < -1f) && _rigidbody.velocity.y < 1f)
                    {
                        if (!_tunnelScreenWrap.TunnelActive())
                        {
                            if (FrameInput.Move.x != 0)
                            {
                                if (!_phasingIn)
                                {
                                    _playerAnimator.PlayAnim("Walk");
                                    _dustStepAnimTimer += Time.deltaTime;
                                    if (_dustStepAnimTimer >= _dustStepAnimDuration)
                                    {
                                        _dustStepAnimTimer = 0;
                                        if (_spriteRenderer.flipX)
                                        {
                                            EffectsController.Instance.CreateEffect("DustStep", _dustSpawnRight.position, Quaternion.identity, new Vector3(-1, 1, 1));
                                        }
                                        else
                                        {
                                            EffectsController.Instance.CreateEffect("DustStep", _dustSpawnLeft.position, Quaternion.identity, new Vector3(1, 1, 1));
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            if (!_phasingOut)
                            {
                                _playerAnimator.PlayAnim("TunnelIdle");
                                _dustStepAnimTimer = 0;
                            }
                        }
                    }
                }
                else
                {
                    if (_rigidbody.velocity.y > 1)
                    {
                        if (!_tunnelScreenWrap.TunnelActive())
                        {
                            if (!_phasingIn)
                            {
                                _playerAnimator.PlayAnim("Jump");
                                _dustStepAnimTimer = 0;
                            }
                        }
                        else
                        {
                            if (!_phasingOut)
                            {
                                _playerAnimator.PlayAnim("TunnelJump");
                                _dustStepAnimTimer = 0;
                            }
                        }
                    }
                    else if (_rigidbody.velocity.y < -1)
                    {
                        if (!_tunnelScreenWrap.TunnelActive())
                        {
                            if (!_phasingIn)
                            {
                                _playerAnimator.PlayAnim("Fall");
                                _dustStepAnimTimer = 0;
                            }
                        }
                        else
                        {
                            if (!_phasingOut)
                            {
                                _playerAnimator.PlayAnim("TunnelFall");
                                _dustStepAnimTimer = 0;
                            }
                        }
                    }
                }
            }
        }

        #endregion

        #region Cammera

        private void HandleCameraCalls()
        {
            if (_grounded)
            {
                if (FrameInput.Move.y < -.85f)
                {
                    Debug.Log("Pressing Down");
                    CameraController.Instance.LookDown(-1);
                }
                else if (FrameInput.Move.y > -.85f && FrameInput.Move.y < .85f)
                {
                    CameraController.Instance.LookDown(0);
                }
                else
                {
                    CameraController.Instance.LookDown(1);
                }
            }
            else
            {
                CameraController.Instance.LookDown(0);
            }
        }

        #endregion

        #region Death

        bool _playerDying = false;

        public void Death()
        {
            if (!_playerDying)
            {
                _tunnelScreenWrap.DisableClock();
                SoundController.Instance.PlaySoundByName("Death");
                _playerDying = true;
                TakeAwayControl();
                _rigidbody.isKinematic = true;
                _playerAnimator.PlayAnim("Death");
                Timer.Instance.AddTimer(.45f, () =>
                {
                    LevelController.Instance.RestartLevel();
                });
            }
        }

        #endregion

        protected virtual void ApplyMovement()
        {
            if (!_hasControl) return;

            if (_tunnelScreenWrap.TunnelActive())
            {
                _rigidbody.velocity = _speed * 1.3f + _currentExternalVelocity;
            }
            else
            {
                _rigidbody.velocity = _speed + _currentExternalVelocity;
            }
            _currentExternalVelocity = Vector2.MoveTowards(_currentExternalVelocity, Vector2.zero, _stats.ExternalVelocityDecay * Time.fixedDeltaTime);
        }

#if UNITY_EDITOR
        private void OnDrawGizmos()
        {
            if (_stats == null) return;

            if (_stats.ShowWallDetection && _standingCollider != null)
            {
                Gizmos.color = Color.white;
                var bounds = GetWallDetectionBounds();
                Gizmos.DrawWireCube(bounds.center, bounds.size);
            }

            if (_stats.AllowLedges && _stats.ShowLedgeDetection)
            {
                Gizmos.color = Color.red;
                var facingDir = Mathf.Sign(WallDirection);
                var grabHeight = transform.position + _stats.LedgeGrabPoint.y * Vector3.up;
                var grabPoint = grabHeight + facingDir * _stats.LedgeGrabPoint.x * Vector3.right;
                Gizmos.DrawWireSphere(grabPoint, 0.05f);
                Gizmos.DrawWireSphere(grabPoint + Vector3.Scale(_stats.StandUpOffset, new(facingDir, 1)), 0.05f);
                Gizmos.DrawRay(grabHeight + _stats.LedgeRaycastSpacing * Vector3.down, 0.5f * facingDir * Vector3.right);
                Gizmos.DrawRay(grabHeight + _stats.LedgeRaycastSpacing * Vector3.up, 0.5f * facingDir * Vector3.right);
            }
        }

        private void OnValidate()
        {
            if (_stats == null) Debug.LogWarning("Please assign a ScriptableStats asset to the Player Controller's Stats slot", this);
            if (_standingCollider == null) Debug.LogWarning("Please assign a Capsule Collider to the Standing Collider slot", this);
            if (_crouchingCollider == null) Debug.LogWarning("Please assign a Capsule Collider to the Crouching Collider slot", this);
            if (_rigidbody == null && !TryGetComponent(out _rigidbody)) Debug.LogWarning("Ensure the GameObject with the Player Controller has a Rigidbody2D", this);
        }
#endif
    }
}
