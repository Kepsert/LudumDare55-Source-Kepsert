using Cinemachine;
using Player;
using System;
using UnityEngine;

[RequireComponent(typeof(PlayerPhysicsMatrixController))]
public class TunnelScreenWrap : MonoBehaviour
{
    [SerializeField] GameObject _tunnelPrefab = null;
    private GameObject _tunnel;
    private CinemachineVirtualCamera _virtualCamera;
    private Camera _cameraComponent;

    [SerializeField] PlayerController _playerController = null;
    [SerializeField] PlayerPhysicsMatrixController _playerPhysicsMatrixController = null;

    ParticleSystem _sparkleParticles = null;

    bool _horizontalTunnel = true;

    [SerializeField] Animator _clockAnim = null;

    [SerializeField] FloatVariable _energyVariable = null;

    const float _rumbleTime = 0.15f;
    float _rumbleTimer = 0;

    private void Start()
    {
        _virtualCamera = FindObjectOfType<CinemachineVirtualCamera>();
        _cameraComponent = GameObject.FindGameObjectWithTag("MainCamera").GetComponent<Camera>();
        if (_playerController == null)
        {
            _playerController = GetComponent<PlayerController>();
        }
        if (_playerPhysicsMatrixController == null)
        {
            _playerPhysicsMatrixController = GetComponent<PlayerPhysicsMatrixController>();
        }
        _playerPhysicsMatrixController.ResetPlayerGroundCollision();

        _clockAnim.Play("Inactive");
    }

    private void OnEnable()
    {
        _playerController.Specialed += SummonTunnel;
        _energyVariable._changedEvent += EnergyGot;
    }

    private void EnergyGot(float obj)
    {
        if (_energyVariable.Value > 0)
        {
            _clockAnim.Play("Active");
        }
        else
        {
            _clockAnim.Play("Inactive");
        }
    }

    private void OnDisable()
    {
        _playerController.Specialed -= SummonTunnel;
        _energyVariable._changedEvent -= EnergyGot;
    }

    private void SummonTunnel(Vector2 position, bool horizontal)
    {
        Toggletunnel(position, horizontal);
    }

    public void DisableClock()
    {
        _clockAnim.GetComponent<SpriteRenderer>().enabled = false;
    }

    private void Update()
    {
        if (TunnelActive())
        {
            _rumbleTimer += Time.deltaTime;
            if (_rumbleTimer >= _rumbleTime)
            {
                _rumbleTimer = 0;
                SoundController.Instance.PlaySoundByName("TunnelRumble");
            }
        }
    }

    void Toggletunnel(Vector2 position, bool horizontal)
    {
        if (_tunnel == null)
        {
            SoundController.Instance.PlaySoundByName("TunnelCreate");
            SoundController.Instance.PlaySoundByName("TunnelRumble");
            CameraController.Instance.ScreenShake(150000, .25f, .8f);
            Vector3 screenPoint = _cameraComponent.WorldToScreenPoint(position);
            _playerPhysicsMatrixController.IgnorePlayerGroundCollision();
            CameraController.Instance.StopFollowing();
            CameraController.Instance.ToggleParticles(true);
            _clockAnim.Play("Inactive");
            _rumbleTimer = 0;
            if (horizontal)
            {
                _horizontalTunnel = true;
                float middleX = _cameraComponent.transform.position.x;
                Vector2 spawnPosition = new Vector2(middleX, position.y);
                _tunnel = Instantiate(_tunnelPrefab, spawnPosition, Quaternion.identity);
                _sparkleParticles = _tunnel.GetComponentInChildren<ParticleSystem>();
                ResizeTunnel(horizontal);

                _sparkleParticles.transform.position = new Vector3(middleX * 3f, position.y);
            }
            else
            {
                _horizontalTunnel = false;
                float middleY = _cameraComponent.transform.position.y;
                Vector2 spawnPosition = new Vector2(position.x, middleY);
                _tunnel = Instantiate(_tunnelPrefab, spawnPosition, Quaternion.identity);
                _sparkleParticles = _tunnel.GetComponentInChildren<ParticleSystem>();
                ResizeTunnel(horizontal);
                _sparkleParticles.transform.position = new Vector3(position.x, middleY * 0.8f);
            }
        }
        else
        {
            SoundController.Instance.PlaySoundByName("TunnelDestroy");
            CameraController.Instance.ScreenShake(0, 0, 0);
            CameraController.Instance.FollowNewTarget(this.transform);
            CameraController.Instance.ToggleParticles(false);
            _playerPhysicsMatrixController.ResetPlayerGroundCollision();
            Destroy(_tunnel);
            _tunnel = null;

            _sparkleParticles.transform.parent = null;
            _sparkleParticles.transform.localScale = new Vector2(1, 1);
            _sparkleParticles.Stop();
            IDestroyable destroyable = _sparkleParticles.GetComponent<IDestroyable>();
            destroyable?.Destroy(1.75f);
        }
    }

    void ResizeTunnel(bool horizontal)
    {
        _sparkleParticles = _tunnel.GetComponentInChildren<ParticleSystem>();
        if (!horizontal)
        {
            float orthographicSize = _virtualCamera.m_Lens.OrthographicSize;

            // OLD: float height = orthographicSize * 2;
            float height = orthographicSize;

            _tunnel.transform.localScale = new Vector3(height, 1, 1f);
            _tunnel.transform.Rotate(0, 0, 90f);
        }
        else
        {
            float ortographicSize = _virtualCamera.m_Lens.OrthographicSize;
            float aspectRatio = Screen.width / (float)Screen.height;

            // OLD: float width = ortographicSize * aspectRatio * 2;
            float width = ortographicSize * aspectRatio;

            _tunnel.transform.localScale = new Vector3(width, 1, 1f);
        }
    }

    public bool TunnelActive()
    {
        if (_tunnel != null)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public void Wrap(GameObject obj)
    {
        if (_tunnel != null)
        {
            Vector3 screenPoint = _cameraComponent.WorldToScreenPoint(obj.transform.position);

            if (_horizontalTunnel)
            {
                if (screenPoint.x < 0 || screenPoint.x > Screen.width)
                {
                    Vector3 newPosition = obj.transform.position;

                    if (screenPoint.x < 0)
                    {
                        // OLD: newPosition.x += _tunnel.transform.localScale.x;
                        newPosition.x += _tunnel.transform.localScale.x * 2;
                    }
                    else if (screenPoint.x > Screen.width)
                    {
                        // OLD: newPosition.x += _tunnel.transform.localScale.x;
                        newPosition.x -= _tunnel.transform.localScale.x * 2;
                    }

                    obj.transform.position = newPosition;
                }
            }
            else
            {
                if (screenPoint.y < 0 || screenPoint.y > Screen.height)
                {
                    Vector3 newPosition = obj.transform.position;
                    
                    if (screenPoint.y < 0)
                    {
                        // OLD: newPosition.y += _tunnel.transform.localScale.x;
                        newPosition.y += _tunnel.transform.localScale.x * 2;
                    }
                    else if (screenPoint.y > Screen.height)
                    {
                        // OLD: newPosition.y += _tunnel.transform.localScale.x;
                        newPosition.y -= _tunnel.transform.localScale.x * 2;
                    }

                    obj.transform.position = newPosition;
                }
            }
        }
    }
}
