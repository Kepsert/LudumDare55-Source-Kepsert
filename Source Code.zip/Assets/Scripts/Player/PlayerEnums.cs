using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Player
{
    public enum PlayerForce
    {
        Burst = 1,
        Decay = 2
    }
}