using Player;
using UnityEngine;

public class PlayerCrushPoint : MonoBehaviour
{
    [SerializeField] Transform _playerCrushPoint = null;
    [SerializeField] float _crushRadius = 0.15f;
    [SerializeField] LayerMask _whatIsGround;
    [SerializeField] PlayerController _playerController;

    bool _active = false;

    bool _crushed = false;

    private void Update()
    {
        if (_active)
        {
            Collider2D[] colliders = Physics2D.OverlapCircleAll(_playerCrushPoint.position, _crushRadius, _whatIsGround);
            for (int i = 0; i < colliders.Length; i++)
            {
                if (colliders[i].gameObject != gameObject && !_crushed)
                {
                    Debug.Log("Getting Crushed");
                    _crushed = true;
                    _playerController.Death();
                }
            }
        }
    }

    public void Toggle(bool value)
    {
        _active = value;
    }
}
