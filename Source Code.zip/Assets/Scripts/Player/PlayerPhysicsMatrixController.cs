using UnityEngine;

public class PlayerPhysicsMatrixController : MonoBehaviour
{
    [SerializeField] string _groundLayerName = "Ground";
    [SerializeField] string _playerLayerName = "Player";

    int layer1;
    int layer2;

    private void Awake()
    {
        layer1 = LayerMask.NameToLayer(_groundLayerName);
        layer2 = LayerMask.NameToLayer(_playerLayerName);
    }

    public void IgnorePlayerGroundCollision()
    {
        Physics2D.IgnoreLayerCollision(layer1, layer2, true);
    }

    public void ResetPlayerGroundCollision()
    {
        Physics2D.IgnoreLayerCollision(layer1, layer2, false);
    }
}
