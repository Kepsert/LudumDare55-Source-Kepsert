using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAnimator : MonoBehaviour
{
    [SerializeField] Animator _anim = null;

    private void Awake()
    {
        if (_anim == null)
        {
            _anim = GetComponentInChildren<Animator>(); 
        }
    }

    public void PlayAnim(string name)
    {
        _anim.Play(name);
    }
}
