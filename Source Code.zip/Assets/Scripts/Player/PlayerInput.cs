using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Player
{
    public class PlayerInput : MonoBehaviour
    {
        public FrameInput FrameInput { get; private set; }

        private void Update() => FrameInput = Gather();

        private PlayerInputActions _actions;
        private InputAction _move, _jump, _dash, _attack, _special;

        private void Awake()
        {
            _actions = new PlayerInputActions();
            _move = _actions.Play.Movement;
            _jump = _actions.Play.Jump;
            _dash = _actions.Play.Dash;
            _attack = _actions.Play.Attack;
            _special = _actions.Play.Special;
        }

        private void OnEnable() => _actions.Enable();

        private void OnDisable() => _actions.Disable();

        private FrameInput Gather()
        {
            return new FrameInput
            {
                JumpDown = _jump.WasPressedThisFrame(),
                JumpHeld = _jump.IsPressed(),
                DashDown = _dash.WasPressedThisFrame(),
                AttackDown = _attack.WasPressedThisFrame(),
                SpecialDown = _special.WasPressedThisFrame(),
                Move = _move.ReadValue<Vector2>(),
            };
        }
    }

    public struct FrameInput
    {
        public Vector2 Move;
        public bool JumpDown;
        public bool JumpHeld;
        public bool DashDown;
        public bool AttackDown;
        public bool SpecialDown;
    }
}