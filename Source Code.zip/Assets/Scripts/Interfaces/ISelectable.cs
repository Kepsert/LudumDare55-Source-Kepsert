using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface ISelectable
{
    ISelectable Trigger();
    ISelectable Untrigger();
    bool Select();
}
