using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IPanelController
{
    List<GameObject> _panelToTurnOn { get; }
    void TogglePanels(GameObject panelToTurnOff, GameObject panelToTurnOn);
}
