using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public interface IMenuOptions
{
    void GetInput(int index, bool disableSelector = true);
    void GetHorizontalInput(int index, int direction);
}
