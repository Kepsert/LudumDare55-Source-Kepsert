using Messaging;
using Messaging.Messages;
using Misc;
using TMPro;
using UnityEngine;

public class EndGameController : MonoBehaviour
{
    [SerializeField] TMP_Text _speedrunText = null;
    [SerializeField] GameObject _continueText = null;
    const float _continueWaitTime = 10;

    bool _canContinue = false;
    bool _pressedContinue = false;

    private void OnEnable()
    {
        MessageHub.Subscribe<ContinueMessage>(this, ContinuePressed);
    }

    private void OnDisable()
    {
        MessageHub.Unsubscribe<ContinueMessage>(this);
    }

    private void ContinuePressed(ContinueMessage obj)
    {
        if (_canContinue && !_pressedContinue)
        {
            _pressedContinue = true;
            LevelController.Instance.LoadNextLevel(0);
        }
    }

    private void Start()
    {
        GameController.Instance.SetGameState(GameState.EndGame);
        MessageHub.Publish(new GameEndedMessage());
        if (GameController.Instance.Mode == GameMode.Speedrun)
        {
            _speedrunText.text = "Speedrun time: " + SpeedrunController.Instance.GetSpeedrunTime();
        }
        else
        {
            _speedrunText.text = "";
        }

        Timer.Instance.AddTimer(_continueWaitTime, () =>
        {
            _continueText.SetActive(true);
            _canContinue = true;
        });
    }
}
