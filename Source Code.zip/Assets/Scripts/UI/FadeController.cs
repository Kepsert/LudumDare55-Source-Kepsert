using System;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class FadeController : MonoBehaviour
{
    public static FadeController Instance;

    [field: SerializeField] public Image _fadeImage { get; private set; } = null;
    [field: SerializeField] public float _fadeDuration { get; private set; } = 0.75f;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            DestroyImmediate(this);
        }
    }

    private void OnEnable()
    {
        SceneManager.sceneLoaded += FadeIn;
    }

    private void OnDisable()
    {
        SceneManager.sceneLoaded -= FadeIn;
    }

    private void FadeIn(Scene arg0, LoadSceneMode arg1)
    {
        _fadeImage.CrossFadeAlpha(0.0f, _fadeDuration, true);
    }

    public void FadeIn()
    {
        _fadeImage.CrossFadeAlpha(0.0f, _fadeDuration, true);
    }

    public void FadeOut()
    {
        _fadeImage.CrossFadeAlpha(1.0f, _fadeDuration, true);
    }
}
