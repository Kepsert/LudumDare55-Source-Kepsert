using Messaging;
using Messaging.Messages;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PauseMenuMainPanelController : MonoBehaviour, IMenuOptions, IPanelController
{
    OptionSelectionHelper _optionSelectionHelper;

    [field: SerializeField] public List<GameObject> _panelToTurnOn { get; private set; } = new List<GameObject>();

    [SerializeField] GameObject _restartSpeedrunButton = null;

    void Awake()
    {
        _optionSelectionHelper = GetComponent<OptionSelectionHelper>();
        if (_optionSelectionHelper == null)
        {
            Debug.LogWarning("MAIN MENU: Couldn't find an option selection helper");
        }
    }

    void OnEnable()
    {
        if (GameController.Instance.Mode != GameMode.Speedrun)
        {
            _optionSelectionHelper.RemoveSelector(_restartSpeedrunButton.GetComponentInChildren<Image>());
            _restartSpeedrunButton.SetActive(false);
            _optionSelectionHelper.ActivateSelectors(3);
        }
    }

    public void GetHorizontalInput(int index, int direction)
    {
        return;
    }

    public void GetInput(int index, bool disableSelector = true)
    {
        if (GameController.Instance.State is GameState.Pause)
        {
            if (GameController.Instance.Mode is GameMode.Normal)
            {
                if (index == 2)
                {
                    index++;
                }
                else if (index == 3)
                {
                    index++;
                }
                Debug.Log(index);
            }
            if (index == 1)
            {
                PauseController.Instance.UnpauseGame(GameState.Playing);
            }
            else if (index == 2)
            {
                LevelController.Instance.LoadNextLevel(1);
                MessageHub.Publish(new NewGameMessage(GameController.Instance.Mode));
                PauseController.Instance.UnpauseGame(GameState.Loading);
            }
            else if (index == 3)
            {
                TogglePanels(this.gameObject, _panelToTurnOn[index]);
            }
            else if (index == 4)
            {
                if (GameController.Instance.Mode is GameMode.Speedrun)
                    MessageHub.Publish(new SpeedrunQuitMessage());
                GameController.Instance.SetGameState(GameState.Loading);
                LevelController.Instance.LoadNextLevel(0);
            }
        }
    }

    public void TogglePanels(GameObject panelToTurnOff, GameObject panelToTurnOn)
    {
        panelToTurnOff.SetActive(false);
        panelToTurnOn.SetActive(true);
    }
}
