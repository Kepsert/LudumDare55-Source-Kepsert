using Messaging;
using Messaging.Messages;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PauseController : MonoBehaviour
{
    public static PauseController Instance;

    [SerializeField] GameObject _pausePanel = null;
    [SerializeField] GameObject _pauseMainPanel = null;
    [SerializeField] GameObject _optionsPanel = null;
    [SerializeField] GameObject _optionsAccessibilityPanel = null;

    private void OnEnable()
    {
        MessageHub.Subscribe<PausePressedMessage>(this, PausePressed);
    }

    private void OnDisable()
    {
        MessageHub.Unsubscribe<PausePressedMessage>(this);
    }

    private void PausePressed(PausePressedMessage obj)
    {
        if (_pausePanel.activeInHierarchy)
        {
            UnpauseGame(GameState.Playing);
        }
        else
        {
            PauseGame();
        }
    }

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            DestroyImmediate(this);
        }
    }

    public void PauseGame()
    {
        _pausePanel.SetActive(true);
        _pauseMainPanel.SetActive(true);

        Time.timeScale = 0f;
        GameController.Instance.SetGameState(GameState.Pause);
    }

    public void UnpauseGame(GameState state)
    {
        Time.timeScale = 1.0f;
        GameController.Instance.SetGameState(state);

        _pausePanel.SetActive(false);
        _pauseMainPanel.SetActive(false);
        _optionsPanel.SetActive(false);
        _optionsAccessibilityPanel.SetActive(false);
    }
}
