using Messaging;
using Messaging.Messages;
using Misc;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class OptionSelectionHelper : MonoBehaviour
{
    [SerializeField] List<Image> _selectorImages = new List<Image>();
    [SerializeField] List<Image> _selectableSelectors = new List<Image>();
    const float _selectedAnimDuration = 0.5f;
    int _selectedIndex = 0;
    int _optionsCount;
    bool _selectorActive;

    private void OnEnable()
    {
        MessageHub.Subscribe<UpPressedMessage>(this, UpPressed);
        MessageHub.Subscribe<DownPressedMessage>(this, DownPressed);
        MessageHub.Subscribe<LeftPressedMessage>(this, LeftPressed);
        MessageHub.Subscribe<RightPressedMessage>(this, RightPressed);
        MessageHub.Subscribe<ContinueMessage>(this, ContinuePressed);

        ResetSelectors();
    }

    private void OnDisable()
    {
        MessageHub.Unsubscribe<UpPressedMessage>(this);
        MessageHub.Unsubscribe<DownPressedMessage>(this);
        MessageHub.Unsubscribe<LeftPressedMessage>(this);
        MessageHub.Unsubscribe<RightPressedMessage>(this);
        MessageHub.Unsubscribe<ContinueMessage>(this);
    }

    private void Start()
    {
        ResetSelectors();
    }

    private void ResetSelectors()
    {
        _selectedIndex = 0;
        _selectorActive = true;
        _optionsCount = _selectorImages.Count;
        HandleSelectors();
    }

    private void UpPressed(UpPressedMessage obj)
    {
        if (_selectorActive)
        {
            _selectedIndex--;
            if (_selectedIndex < 0)
            {
                _selectedIndex = _optionsCount - 1;
            }
            if (GameController.Instance.State is GameState.Pause || GameController.Instance.State is GameState.MainMenu || GameController.Instance.State is GameState.Dialogue || GameController.Instance.State is GameState.Cutscene)
                SoundController.Instance.PlaySoundByName("ChangeSelection");
            HandleSelectors();
        }
    }

    private void DownPressed(DownPressedMessage obj)
    {
        if (_selectorActive)
        {
            _selectedIndex++;
            if (_selectedIndex == _optionsCount)
            {
                _selectedIndex = 0;
            }
            if (GameController.Instance.State is GameState.Pause || GameController.Instance.State is GameState.MainMenu || GameController.Instance.State is GameState.Dialogue || GameController.Instance.State is GameState.Cutscene)
                SoundController.Instance.PlaySoundByName("ChangeSelection");
            HandleSelectors();
        }
    }

    private void LeftPressed(LeftPressedMessage obj)
    {
        if (_selectorActive)
        {
            IMenuOptions menuOptions = GetComponent<IMenuOptions>();

            if (menuOptions != null)
            {
                menuOptions.GetHorizontalInput(_selectedIndex + 1, -1);
            }
            else
            {
                Debug.LogWarning("SelectionHelper: There's no IMenuOptions to call to");
            }
        }
    }

    private void RightPressed(RightPressedMessage obj)
    {
        if (_selectorActive)
        {
            IMenuOptions menuOptions = GetComponent<IMenuOptions>();

            if (menuOptions != null)
            {
                menuOptions.GetHorizontalInput(_selectedIndex + 1, 1);
            }
            else
            {
                Debug.LogWarning("SelectionHelper: There's no IMenuOptions to call to");
            }
        }
    }

    private void HandleSelectors()
    {
        for (int i = 0; i < _optionsCount; i++)
        {
            _selectorImages[i].enabled = false;
            if (i == _selectedIndex)
            {
                _selectorImages[i].enabled = true;
            }
        }
    }

    public void RemoveSelector(Image selector)
    {
        if (_selectorImages.Contains(selector))
        {
            _selectorImages.Remove(selector);
        }
        if (_selectableSelectors.Contains(selector))
        {
            _selectableSelectors.Remove(selector);
        }
    }

    int count = 0;
    private void ContinuePressed(ContinueMessage obj)
    {
        if (GameController.Instance.State is not GameState.EndGame)
        {
            count++;
            if (_selectorActive)
            {
                IMenuOptions menuOptions = GetComponent<IMenuOptions>();
                if (menuOptions != null)
                {
                    if (GameController.Instance.State != GameState.Intro && GameController.Instance.State != GameState.Dialogue)
                        SoundController.Instance.PlaySoundByName("MenuSelect");

                    if (_selectableSelectors.Contains(_selectorImages[_selectedIndex]))
                    {
                        StartCoroutine(SelectedOptionCoroutine(_selectorImages[_selectedIndex], menuOptions));
                        _selectorActive = false;
                    }
                    else
                    {
                        menuOptions.GetInput(_selectedIndex + 1);
                    }
                }
                else
                {
                    Debug.LogWarning("SelectionHelper: There's no IMenuOptions to call to");
                }
            }
        }
    }

    private IEnumerator SelectedOptionCoroutine(Image img, IMenuOptions menuOptions)
    {
        int flashCount = 6;
        for (int i = 0; i < flashCount; i++)
        {
            img.enabled = !img.enabled;
            yield return new WaitForSecondsRealtime(_selectedAnimDuration / flashCount);
        }
        img.enabled = true;
        yield return new WaitForSecondsRealtime(0.2f);
        img.enabled = false;
        menuOptions.GetInput(_selectedIndex + 1);
    }

    public void ActivateSelectors(int optionsCount)
    {
        _selectedIndex = 0;
        foreach (Image img in _selectorImages)
        {
            img.enabled = false;
        }
        _optionsCount = optionsCount;
        _selectorActive = true;
        HandleSelectors();
    }

    public void ReEnableSelectors()
    {
        foreach (Image img in _selectorImages)
        {
            img.enabled = false;
        }
        _selectorActive = true;
        HandleSelectors();
    }
}
