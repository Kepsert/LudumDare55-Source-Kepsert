using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MainMenuOptionsAccessibilityPanel : MonoBehaviour, IMenuOptions, IPanelController
{
    [field: SerializeField] public List<GameObject> _panelToTurnOn { get; private set; } = new List<GameObject>();

    [SerializeField] BoolVariable _screenshakeVariable = null;
    [SerializeField] BoolVariable _replayDialogueVariable = null;

    [SerializeField] Image _screenshakeCheckmark = null;
    [SerializeField] Image _replayDialogueCheckmark = null;


    void OnEnable()
    {
        _screenshakeCheckmark.enabled = _screenshakeVariable.Value;
        _replayDialogueCheckmark.enabled = _replayDialogueVariable.Value;
    }

    public void GetHorizontalInput(int index, int direction)
    {
        return;
    }

    public void GetInput(int index, bool disableSelector = true)
    {
        OptionSelectionHelper osh = GetComponent<OptionSelectionHelper>();
        switch (index)
        {
            case 1:
                _screenshakeCheckmark.enabled = !_screenshakeCheckmark.enabled;
                _screenshakeVariable.ChangeValue(_screenshakeCheckmark.enabled, false);
                if (osh != null)
                {
                    osh.ReEnableSelectors();
                }
                else
                {
                    Debug.LogWarning("MainMenuOptionsController: No OptionSelectionHelper");
                }
                break;
            case 2:
                _replayDialogueCheckmark.enabled = !_replayDialogueCheckmark.enabled;
                _replayDialogueVariable.ChangeValue(_replayDialogueCheckmark.enabled, false);
                if (osh != null)
                {
                    osh.ReEnableSelectors();
                }
                else
                {
                    Debug.LogWarning("MainMenuOptionsController: No OptionSelectionHelper");
                }
                break;
            case 3:
                TogglePanels(this.gameObject, _panelToTurnOn[index]);
                break;
        }
    }

    public void TogglePanels(GameObject panelToTurnOff, GameObject panelToTurnOn)
    {
        panelToTurnOff.SetActive(false);
        panelToTurnOn.SetActive(true);
    }
}
