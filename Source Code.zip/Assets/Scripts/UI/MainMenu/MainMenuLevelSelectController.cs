using Messaging;
using Messaging.Messages;
using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class MainMenuLevelSelectController : MonoBehaviour, IMenuOptions, IPanelController
{
    [field: SerializeField] public List<GameObject> _panelToTurnOn { get; private set; } = new List<GameObject>();
    [SerializeField] TMP_Text _levelText = null;

    private int _lastLevel = 0;

    private void Awake()
    {
        _lastLevel = PlayerPrefs.GetInt("SavedGame");

        _levelText.text = _lastLevel.ToString();
    }

    public void GetHorizontalInput(int index, int direction)
    {
        if (index == 1)
        {
            int level = Convert.ToInt32(_levelText.text);
            if (direction == 1)
            {
                level++;
                if (level > _lastLevel)
                {
                    level = 1;
                }
            }
            else
            {
                level--;
                if (level < 1)
                {
                    level = _lastLevel;
                }
            }
            UpdateLevelText(level);
        }
    }

    private void UpdateLevelText(int level)
    {
        _levelText.text = level.ToString();
    }

    public void GetInput(int index, bool disableSelector = true)
    {
        if (index == 1)
        {
            GameController.Instance.SetGameMode(GameMode.Normal);
            MessageHub.Publish(new NewGameMessage(GameMode.Normal));
            LevelController.Instance.LoadNextLevel(Convert.ToInt32(_levelText.text));
        }
        if (index == 2)
        {
            TogglePanels(this.gameObject, _panelToTurnOn[index]);
        }
    }

    public void TogglePanels(GameObject panelToTurnOff, GameObject panelToTurnOn)
    {
        panelToTurnOff.SetActive(false);
        panelToTurnOn.SetActive(true);
    }
}
