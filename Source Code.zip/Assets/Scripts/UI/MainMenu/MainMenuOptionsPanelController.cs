using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class MainMenuOptionsPanelController : MonoBehaviour, IMenuOptions, IPanelController
{
    [field: SerializeField] public List<GameObject> _panelToTurnOn { get; private set; } = new List<GameObject>();

    [SerializeField] TMP_Text _masterVolumeText = null;
    [SerializeField] TMP_Text _musicVolumeText = null;
    [SerializeField] TMP_Text _sfxVolumeText = null;

    [SerializeField] FloatVariable _masterVolumeVariable = null;
    [SerializeField] FloatVariable _musicVolumeVariable = null;
    [SerializeField] FloatVariable _sfxVolumeVariable = null;

    [SerializeField] BoolVariable _replayDialogueVariable = null;

    void OnEnable()
    {
        _masterVolumeText.text = (_masterVolumeVariable.Value * 10).ToString();
        _musicVolumeText.text = (_musicVolumeVariable.Value * 10).ToString();
        _sfxVolumeText.text = (_sfxVolumeVariable.Value * 10).ToString();
    }

    public void GetHorizontalInput(int index, int direction)
    {
        int masterVolume = Convert.ToInt32(_masterVolumeText.text);
        int musicVolume = Convert.ToInt32(_musicVolumeText.text);
        int sfxVolume = Convert.ToInt32(_sfxVolumeText.text);
        if (direction == -1)
        {
            switch (index)
            {
                case 1:
                    SoundController.Instance.PlaySoundByName("ChangeSelection");
                    masterVolume--;
                    break;
                case 2:
                    SoundController.Instance.PlaySoundByName("ChangeSelection");
                    musicVolume--;
                    break;
                case 3:
                    SoundController.Instance.PlaySoundByName("ChangeSelection");
                    sfxVolume--;
                    break;
            }
        }
        else
        {
            switch (index)
            {
                case 1:
                    SoundController.Instance.PlaySoundByName("ChangeSelection");
                    masterVolume++;
                    break;
                case 2:
                    SoundController.Instance.PlaySoundByName("ChangeSelection");
                    musicVolume++;
                    break;
                case 3:
                    SoundController.Instance.PlaySoundByName("ChangeSelection");
                    sfxVolume++;
                    break;
            }
        }

        if (masterVolume < 0)
        {
            masterVolume = 0;
        }
        else if (masterVolume > 10)
        {
            masterVolume = 10;
        }

        if (musicVolume < 0)
        {
            musicVolume = 0;
        }
        else if (musicVolume > 10)
        {
            musicVolume = 10;
        }
        if (sfxVolume < 0)
        {
            sfxVolume = 0;
        }
        else if (sfxVolume > 10)
        {
            sfxVolume = 10;
        }

        _masterVolumeText.text = masterVolume.ToString();
        _musicVolumeText.text = musicVolume.ToString();
        _sfxVolumeText.text = sfxVolume.ToString();

        _masterVolumeVariable.ChangeValue((float)masterVolume / 10, true);
        _musicVolumeVariable.ChangeValue((float)musicVolume / 10, true);
        _sfxVolumeVariable.ChangeValue((float)sfxVolume / 10, true);
    }

    public void GetInput(int index, bool disableSelector = true)
    {
        if (index == 4)
        {
            TogglePanels(this.gameObject, _panelToTurnOn[index]);
        }
        if (index == 5)
        {
            TogglePanels(this.gameObject, _panelToTurnOn[index]);
        }
    }

    public void TogglePanels(GameObject panelToTurnOff, GameObject panelToTurnOn)
    {
        panelToTurnOff.SetActive(false);
        panelToTurnOn.SetActive(true);
    }
}
