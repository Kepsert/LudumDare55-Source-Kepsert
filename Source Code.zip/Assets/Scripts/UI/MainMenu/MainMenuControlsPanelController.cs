using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainMenuControlsPanelController : MonoBehaviour, IMenuOptions, IPanelController
{
    [field: SerializeField] public List<GameObject> _panelToTurnOn { get; private set; }

    public void GetHorizontalInput(int index, int direction)
    {
        return;
    }

    public void GetInput(int index, bool disableSelector = true)
    {
        if (index == 1)
        {
            TogglePanels(this.gameObject, _panelToTurnOn[index]);
        }
    }

    public void TogglePanels(GameObject panelToTurnOff, GameObject panelToTurnOn)
    {
        panelToTurnOff.SetActive(false);
        panelToTurnOn.SetActive(true);
    }
}
