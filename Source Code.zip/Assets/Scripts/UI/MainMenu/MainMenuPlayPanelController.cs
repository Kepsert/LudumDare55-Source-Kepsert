using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MainMenuPlayPanelController : MonoBehaviour, IMenuOptions, IPanelController
{
    OptionSelectionHelper _optionSelectionHelper;
    [field: SerializeField] public List<GameObject> _panelToTurnOn { get; private set; } = new List<GameObject>();
    [SerializeField] GameObject _loadButton = null;
    bool _savedGameExists = false;

    void Awake()
    {
        _optionSelectionHelper = GetComponent<OptionSelectionHelper>();
        if (_optionSelectionHelper == null)
        {
            Debug.LogWarning("MAIN MENU: Couldn't find an option selection helper");
        }
    }

    void OnEnable()
    {
        if (!PlayerPrefs.HasKey("SavedGame"))
        {
            _savedGameExists = false;
            _optionSelectionHelper.RemoveSelector(_loadButton.GetComponentInChildren<Image>());
            _loadButton.SetActive(false);
            _optionSelectionHelper.ActivateSelectors(3);
        }
        else
        {
            _savedGameExists = true;
        }
    }

    public void GetHorizontalInput(int index, int direction)
    {
        return;
    }

    public void GetInput(int index, bool disableSelector = true)
    {
        if (!_savedGameExists)
        {
            if (index==2)
            {
                index++;
            }
            else if (index == 3)
            {
                index++;
            }
            Debug.Log(index);
        }
        switch (index)
        {
            case 1:
                TogglePanels(this.gameObject, _panelToTurnOn[index]);
                break;
            case 2:
                TogglePanels(this.gameObject, _panelToTurnOn[index]);
                break;
            case 3:
                TogglePanels(this.gameObject, _panelToTurnOn[index]);
                break;
            case 4:
                TogglePanels(this.gameObject, _panelToTurnOn[index]);
                break;
        }
    }

    public void TogglePanels(GameObject panelToTurnOff, GameObject panelToTurnOn)
    {
        panelToTurnOff.SetActive(false);
        panelToTurnOn.SetActive(true);
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
