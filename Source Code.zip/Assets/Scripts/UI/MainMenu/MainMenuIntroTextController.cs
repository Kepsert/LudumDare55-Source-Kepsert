using Messaging.Messages;
using Messaging;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class MainMenuIntroTextController : MonoBehaviour, IPanelController
{
    [SerializeField] GameObject _introText = null;

    const float _selectedAnimDuration = 0.75f;

    bool _active = true;

    [field: SerializeField] public List<GameObject> _panelToTurnOn { get; private set; } = new List<GameObject>();

    private void OnEnable()
    {
        PauseController.Instance.UnpauseGame(GameState.MainMenu);
        MessageHub.Subscribe<ContinueMessage>(this, ContinuePressed);

        Time.timeScale = 1.0f;
    }

    private void OnDisable()
    {
        MessageHub.Unsubscribe<ContinueMessage>(this);
    }

    private void Start()
    {
        SoundController.Instance.ChangeMusic("");
        GameController.Instance.SetGameState(GameState.Intro);
    }

    private void ContinuePressed(ContinueMessage obj)
    {
        if (_active)
        {
            SoundController.Instance.PlaySoundByName("StartGame");
            _active = false;
            StartCoroutine(SelectedOptionCoroutine());
        }
    }

    private IEnumerator SelectedOptionCoroutine()
    {
        int flashCount = 8;
        for (int i = 0; i < flashCount; i++)
        {
            _introText.SetActive(!_introText.activeInHierarchy);
            yield return new WaitForSeconds(_selectedAnimDuration / flashCount);
        }
        _introText.SetActive(true);
        yield return new WaitForSeconds(0.2f);
        TogglePanels(this.gameObject, _panelToTurnOn[0]);
    }

    public void TogglePanels(GameObject panelToTurnOff, GameObject panelToTurnOn)
    {
        panelToTurnOff.SetActive(false);
        panelToTurnOn.SetActive(true);
    }
}
