using Messaging;
using Messaging.Messages;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainMenuNewGameController : MonoBehaviour, IMenuOptions, IPanelController
{
    [field: SerializeField] public List<GameObject> _panelToTurnOn { get; private set; } = new List<GameObject>();

    public void GetHorizontalInput(int index, int direction)
    {
        return;
    }

    public void GetInput(int index, bool disableSelector = true)
    {
        switch (index)
        {
            case 1:
                TogglePanels(this.gameObject, _panelToTurnOn[index]);
                break;
            case 2:
                PlayerPrefs.DeleteKey("SavedGame");
                GameController.Instance.SetGameMode(GameMode.Normal);
                MessageHub.Publish(new NewGameMessage(GameMode.Normal));
                LevelController.Instance.LoadNextLevel();
                break;
        }
    }

    public void TogglePanels(GameObject panelToTurnOff, GameObject panelToTurnOn)
    {
        panelToTurnOff.SetActive(false);
        panelToTurnOn.SetActive(true);
    }
}
