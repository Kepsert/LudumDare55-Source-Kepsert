using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[RequireComponent(typeof(OptionSelectionHelper))]
public class MainMenuMainPanelController : MonoBehaviour, IMenuOptions, IPanelController
{
    OptionSelectionHelper _optionSelectionHelper;

    [field: SerializeField] public List<GameObject> _panelToTurnOn { get; private set; } = new List<GameObject>();
    [SerializeField] GameObject _exitButton = null;

    private void OnEnable()
    {
        SoundController.Instance.ChangeMusic("Menu");

        GameController.Instance.SetGameState(GameState.MainMenu);

#if UNITY_WEBGL
        _optionSelectionHelper.RemoveSelector(_exitButton.GetComponentInChildren<Image>());
        _exitButton.SetActive(false);
#endif
    }

    private void Awake()
    {
        if (_optionSelectionHelper == null)
        {
            _optionSelectionHelper = GetComponent<OptionSelectionHelper>();
        }
    }

    public void GetInput(int index, bool disableSelector = true)
    {
        switch (index)
        {
            case 1:
                TogglePanels(this.gameObject, _panelToTurnOn[index]);
                break;
            case 2:
                TogglePanels(this.gameObject, _panelToTurnOn[index]);
                break;
            case 3:
                TogglePanels(this.gameObject, _panelToTurnOn[index]);
                break;
            case 4:
                Application.Quit();
                break;
        }
    }

    public void TogglePanels(GameObject panelToTurnOff, GameObject panelToTurnOn)
    {
        panelToTurnOff.SetActive(false);
        panelToTurnOn.SetActive(true);
    }

    public void GetHorizontalInput(int index, int direction)
    {
        return;
    }
}
