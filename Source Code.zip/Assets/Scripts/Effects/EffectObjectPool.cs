using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EffectObjectPool : MonoBehaviour
{
    public static EffectObjectPool Instance;

    public Dictionary<GameObject, List<GameObject>> _poolDictionary = new Dictionary<GameObject, List<GameObject>>();

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            DestroyImmediate(this);
        }
    }

    public GameObject GetObjectFromPool(GameObject prefab, Vector3 position, Quaternion rotation, Transform parent = null)
    {
        if (_poolDictionary.ContainsKey(prefab))
        {
            foreach (GameObject obj in _poolDictionary[prefab])
            {
                if (!obj.activeInHierarchy)
                {
                    obj.transform.position = position;
                    obj.transform.rotation = rotation;
                    obj.transform.localScale = prefab.transform.localScale;

                    obj.SetActive(true);

                    if (parent != null)
                    {
                        obj.transform.parent = parent;
                    }

                    return obj;
                }
            }
        }

        GameObject newObj = Instantiate(prefab, position, rotation);
        if (parent != null)
        {
            newObj.transform.parent = parent;
        }
        if (!_poolDictionary.ContainsKey(prefab))
        {
            _poolDictionary[prefab] = new List<GameObject>();
        }

        _poolDictionary[prefab].Add(newObj);

        return newObj;
    }
}
