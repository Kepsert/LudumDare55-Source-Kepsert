using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "EFFECT_", menuName = "Effects/Effect")]
public class Effect : ScriptableObject
{
    [field: SerializeField] public GameObject _prefab { get; private set; } = null;
    [field: SerializeField] public float _duration { get; private set; } = 0f;

    public void PlayEffect(Vector3 position, Quaternion rotation, Vector3 scale, Transform parent = null)
    {
        GameObject effectObject = EffectObjectPool.Instance.GetObjectFromPool(_prefab, position, rotation, parent);
        effectObject.transform.localScale = scale;

        // Start the coroutine for deactivation
        CoroutineUtility.Instance.StartCoroutine(DeactivateAfterDuration(effectObject));
    }

    private IEnumerator DeactivateAfterDuration(GameObject obj)
    {
        obj.transform.SetParent(EffectObjectPool.Instance.gameObject.transform);
        yield return new WaitForSeconds(_duration);
        obj.SetActive(false);
    }
}
