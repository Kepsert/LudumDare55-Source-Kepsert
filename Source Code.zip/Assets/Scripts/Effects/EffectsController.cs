using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EffectsController : MonoBehaviour
{
    public static EffectsController Instance;

    [SerializeField] List<Effect> _effectList = new List<Effect>();

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            DestroyImmediate(Instance);
        }
    }

    public void CreateEffect(string name, Vector3 position, Quaternion rotation, Vector3 scale, Transform parent = null)
    {
        Effect effect = _effectList.Find(x => x.name == name);

        if (effect != null)
        {
            effect.PlayEffect(position, rotation, scale, parent);
        }
        else
        {
            Debug.LogWarning("EFFECT: Effect with name '" + name + "' not found.");
        }
    }
}
