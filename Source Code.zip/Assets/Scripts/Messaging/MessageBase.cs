using System;
using UnityEngine;

namespace Messaging
{
    public class MessageBase
    {
        public Guid Uid { get; } = Guid.NewGuid();
    }
}
