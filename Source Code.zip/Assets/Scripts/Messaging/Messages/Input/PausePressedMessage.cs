namespace Messaging.Messages
{
    public class PausePressedMessage : MessageBase
    {
        public PausePressedMessage()
        {

        }
    }
}
