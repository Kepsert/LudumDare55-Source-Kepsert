namespace Messaging.Messages
{
    public class ContinueMessage : MessageBase
    {
        public ContinueMessage()
        {

        }
    }
}