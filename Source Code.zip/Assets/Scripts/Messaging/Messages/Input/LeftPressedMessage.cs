namespace Messaging.Messages
{

    public class LeftPressedMessage : MessageBase
    {
        public LeftPressedMessage()
        {

        }
    }
}