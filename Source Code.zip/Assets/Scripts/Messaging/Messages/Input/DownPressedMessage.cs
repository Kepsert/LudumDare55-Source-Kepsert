namespace Messaging.Messages
{

    public class DownPressedMessage : MessageBase
    {
        public DownPressedMessage()
        {

        }
    }
}