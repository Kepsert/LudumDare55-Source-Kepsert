namespace Messaging.Messages
{
    public class SkipPressedMessage : MessageBase
    {
        public SkipPressedMessage()
        {

        }
    }
}
