namespace Messaging.Messages
{

    public class UpPressedMessage : MessageBase
    {
        public UpPressedMessage()
        {

        }
    }
}