namespace Messaging.Messages
{

    public class RestartPressedMessage : MessageBase
    {
        public RestartPressedMessage()
        {

        }
    }
}
