namespace Messaging.Messages
{

    public class RightPressedMessage : MessageBase
    {
        public RightPressedMessage()
        {

        }
    }
}