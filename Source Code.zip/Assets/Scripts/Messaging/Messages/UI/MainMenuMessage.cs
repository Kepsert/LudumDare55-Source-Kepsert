namespace Messaging.Messages
{
    public class MainMenuMessage : MessageBase
    {
        public MainMenuMessage()
        {

        }
    }
}