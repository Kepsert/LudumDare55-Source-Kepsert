namespace Messaging.Messages
{

    public class DialogueEndedMessage : MessageBase
    {
        public DialogueEndedMessage()
        {

        }
    }
}
