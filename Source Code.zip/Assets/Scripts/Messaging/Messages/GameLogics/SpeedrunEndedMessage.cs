namespace Messaging.Messages
{
    public class SpeedrunEnded : MessageBase
    {
        public SpeedrunEnded()
        {

        }
    }
}
