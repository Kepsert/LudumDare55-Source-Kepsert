namespace Messaging.Messages
{
    public class GameEndedMessage : MessageBase
    {
        public GameEndedMessage()
        {

        }
    }
}
