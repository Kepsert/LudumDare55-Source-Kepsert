namespace Messaging.Messages {
    public class LevelStartedMessage : MessageBase
    {
        public int Level { get; }
        public LevelStartedMessage(int level = 0)
        {
            Level = level;
        }
    }
}
