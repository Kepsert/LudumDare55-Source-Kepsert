namespace Messaging.Messages {

    public class LevelEndedMessage : MessageBase
    {
        public LevelEndedMessage()
        {

        }
    }
}
