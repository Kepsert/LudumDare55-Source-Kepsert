namespace Messaging.Messages
{
    public class SpeedrunQuitMessage : MessageBase
    {
        public SpeedrunQuitMessage()
        {

        }
    }
}
