namespace Messaging.Messages
{
    public class NewGameMessage : MessageBase 
    {
        public GameMode Mode;
        public NewGameMessage(GameMode mode)
        {
            Mode = mode;
        }
    }
}