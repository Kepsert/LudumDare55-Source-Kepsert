using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CutscenePool : MonoBehaviour
{
    public static CutscenePool Instance;

    [SerializeField] List<Cutscene> _cutsceneList = new List<Cutscene>();

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            DestroyImmediate(this);
        }
    }

    public Cutscene GetCutsceneByName(int index)
    {
        Cutscene cutscene = _cutsceneList[index];
        if (cutscene == null)
        {
            Debug.LogWarning("CUTSCENE POOL: Cutscene doesn't exist at index " + index);
            return null;
        }
        return cutscene;
    }
}
