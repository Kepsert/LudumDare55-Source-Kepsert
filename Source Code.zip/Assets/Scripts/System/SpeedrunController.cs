using Messaging;
using Messaging.Messages;
using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class SpeedrunController : MonoBehaviour
{
    public static SpeedrunController Instance;

    [SerializeField] GameObject _speedrunPanel = null;
    [SerializeField] TMP_Text _speedrunText = null;

    bool _speedrunActive = false;
    float _speedrunTimer = 0;

    public TimeSpan _ts;

    string _finalTimeText;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            DestroyImmediate(this);
        }
    }

    private void OnEnable()
    {
        MessageHub.Subscribe<NewGameMessage>(this, NewGame);
        MessageHub.Subscribe<GameEndedMessage>(this, GameEnded);
        MessageHub.Subscribe<SpeedrunQuitMessage>(this, SpeedrunEnded);
    }

    private void OnDisable()
    {
        MessageHub.Unsubscribe<NewGameMessage>(this);
        MessageHub.Unsubscribe<GameEndedMessage>(this);
        MessageHub.Unsubscribe<SpeedrunQuitMessage>(this);
    }

    private void NewGame(NewGameMessage obj)
    {
        if (obj.Mode is GameMode.Speedrun)
        {
            _speedrunActive = true;
            _speedrunTimer = 0;
            _speedrunPanel.SetActive(true);
        }
        else
        {
            _speedrunActive = false;
            _speedrunTimer = 0;
            _speedrunPanel.SetActive(false);
        }
    }

    private void GameEnded(GameEndedMessage obj)
    {
        _speedrunPanel.SetActive(false);
        _speedrunActive = false;
        _finalTimeText = _speedrunText.text;
    }

    private void SpeedrunEnded(SpeedrunQuitMessage obj)
    {
        _speedrunPanel.SetActive(false);
        _speedrunTimer = 0;
    }

    private void Update()
    {
        if (_speedrunActive)
        {
            if (GameController.Instance.State is GameState.Playing)
            {
                _speedrunTimer += Time.deltaTime;
                _ts = TimeSpan.FromSeconds(_speedrunTimer);
                _speedrunText.text = string.Format("{0}:{1:00}:{2:00}", _ts.Hours, _ts.Minutes, _ts.Seconds);
            }
        }
    }

    public string GetSpeedrunTime()
    {
        return _finalTimeText;
    }
}
