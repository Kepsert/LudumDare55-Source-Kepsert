using Messaging;
using Messaging.Messages;
using UnityEngine;
using UnityEngine.InputSystem;

public class InputHandler : MonoBehaviour
{
    public static InputHandler Instance;

    public Vector2 Move { get; private set; } = Vector2.zero;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            DestroyImmediate(this);
        }
    }

    public void MoveFunction(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            Move = context.ReadValue<Vector2>();
        }
    }

    public void UpFunction(InputAction.CallbackContext context)
    {
        if (context.started)
        {
            if (GameController.Instance.State is GameState.Dialogue || GameController.Instance.State is GameState.Cutscene || GameController.Instance.State is GameState.MainMenu || GameController.Instance.State is GameState.Pause)
            {
                MessageHub.Publish(new UpPressedMessage());
            }
            if (GameController.Instance.State is GameState.Playing)
            {
                MessageHub.Publish(new UpPressedMessage());
            }
        }
    }

    public void DownFunction(InputAction.CallbackContext context)
    {
        if (context.started)
        {
            if (GameController.Instance.State is GameState.Dialogue || GameController.Instance.State is GameState.Cutscene || GameController.Instance.State is GameState.MainMenu || GameController.Instance.State is GameState.Pause)
            {
                MessageHub.Publish(new DownPressedMessage());
            }
        }
    }

    public void LeftFunction(InputAction.CallbackContext context)
    {
        if (context.started)
        {
            if (GameController.Instance.State is GameState.Dialogue || GameController.Instance.State is GameState.Cutscene || GameController.Instance.State is GameState.MainMenu || GameController.Instance.State is GameState.Pause)
            {
                MessageHub.Publish(new LeftPressedMessage());
            }
        }
    }

    public void RightFunction(InputAction.CallbackContext context)
    {
        if (context.started)
        {
            if (GameController.Instance.State is GameState.Dialogue || GameController.Instance.State is GameState.Cutscene || GameController.Instance.State is GameState.MainMenu || GameController.Instance.State is GameState.Pause)
            {
                MessageHub.Publish(new RightPressedMessage());
            }
        }
    }


    public void ContinueFunction(InputAction.CallbackContext context)
    {
        if (context.started)
        {
            if (GameController.Instance.State is GameState.Dialogue || GameController.Instance.State is GameState.Cutscene || GameController.Instance.State is GameState.MainMenu || GameController.Instance.State is GameState.Pause
                || GameController.Instance.State is GameState.Intro || GameController.Instance.State is GameState.EndGame)
            {
                MessageHub.Publish(new ContinueMessage());
            }
        }
    }

    public void PauseFunction(InputAction.CallbackContext context)
    {
        if (context.started)
        {
            if (GameController.Instance.State is GameState.Pause || GameController.Instance.State is GameState.Playing)
            {
                MessageHub.Publish(new PausePressedMessage());
            }
        }
    }

    public void RestartFunction(InputAction.CallbackContext context)
    {
        if (context.started)
        {
            if (GameController.Instance.State is GameState.Playing)
            {
                MessageHub.Publish(new RestartPressedMessage());
            }
        }
    }

    public void SkipFunction(InputAction.CallbackContext context)
    {
        if (context.started)
        {
            if (GameController.Instance.State is GameState.Playing)
            {
                MessageHub.Publish(new SkipPressedMessage());
            }
        }
    }
}
