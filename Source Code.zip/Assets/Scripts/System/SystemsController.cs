using Misc;
using UnityEngine;

namespace Systems
{
    public class SystemsController : Singleton<SystemsController>
    {
        [SerializeField] GameObject _systemsPrefab = null;

        private void Awake()
        {
            base.Awake();

            Screen.SetResolution(1920, 1080, true);

            if (FindObjectOfType<GameController>() == null)
            {
                Instantiate(_systemsPrefab);
            }
        }
    }
}
