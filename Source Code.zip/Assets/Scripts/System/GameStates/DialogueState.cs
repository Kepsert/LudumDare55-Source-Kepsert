using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DialogueState : IGameState
{
    public void EnterState()
    {
        Debug.Log("Entering Dialogue State");
    }

    public void ExitState()
    {
        throw new System.NotImplementedException();
    }

    public void UpdateState()
    {
        Debug.Log("Exiting Dialogue State");
    }
}
