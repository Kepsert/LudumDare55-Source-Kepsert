using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PauseState : IGameState
{
    public void EnterState()
    {
        Debug.Log("Entering Pause State");
    }

    public void UpdateState()
    {
        // Update logic for main menu state
    }

    public void ExitState()
    {
        Debug.Log("Exiting Pause State");
    }
}
