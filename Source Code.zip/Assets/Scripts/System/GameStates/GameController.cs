using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public enum GameState { Playing, Pause, MainMenu, Dialogue, Cutscene, Loading, Intro, EndGame }
public enum GameMode { Normal = 0, Speedrun = 1 }
public class GameController : MonoBehaviour
{
    public static GameController Instance;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            DestroyImmediate(this);
        }
    }

    [field: SerializeField] public GameState State { get; private set; } = GameState.MainMenu;
    [field: SerializeField] public GameMode Mode { get; private set; } = GameMode.Normal;

    public void SetGameState(GameState state)
    {
        State = state;
    }

    public void SetGameMode(GameMode mode)
    {
        Mode = mode;
    }
}
