using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayingState : IGameState
{
    public void EnterState()
    {
        Debug.Log("Entering Playing State");
    }

    public void UpdateState()
    {
        // Update logic for main menu state
    }

    public void ExitState()
    {
        Debug.Log("Exiting Playing State");
    }
}
