
using UnityEngine;

public interface IGameState
{
    void EnterState();
    void UpdateState();
    void ExitState();
}
