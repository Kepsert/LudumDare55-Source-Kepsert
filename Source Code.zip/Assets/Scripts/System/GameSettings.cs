using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameSettings : MonoBehaviour
{
    public static GameSettings Instance;

    [field: SerializeField] public FloatVariable MasterVolume { get; private set; } = null;
    [field: SerializeField] public FloatVariable MusicVolume { get; private set; } = null;
    [field: SerializeField] public FloatVariable SFXVolume { get; private set; } = null;
    [field: SerializeField] public BoolVariable ReplayDialogue { get; private set; } = null;
    [field: SerializeField] public BoolVariable Screenshake { get; private set; } = null;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            DestroyImmediate(this);
        }

        if (!PlayerPrefs.HasKey("OptionsInitialized"))
        {
            MasterVolume.ChangeValue(0.5f, false);
            MusicVolume.ChangeValue(0.2f, false);
            SFXVolume.ChangeValue(0.2f, false);
            ReplayDialogue.ChangeValue(false, false);
            Screenshake.ChangeValue(true, false);
            PlayerPrefs.SetInt("OptionsInitialized", 1);
        }
    }
}
