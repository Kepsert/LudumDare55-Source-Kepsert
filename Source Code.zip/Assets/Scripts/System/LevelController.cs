using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelController : MonoBehaviour
{
    public static LevelController Instance;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            DestroyImmediate(this);
        }
    }

    public void LoadNextLevel(int levelToLoad = -1)
    {
        FadeController.Instance.FadeOut(); // Start fade out
        GameController.Instance.SetGameState(GameState.Loading);
        StartCoroutine(LoadNextLevelDelayed(levelToLoad));
    }

    public void RestartLevel()
    {
        FadeController.Instance.FadeOut();
        GameController.Instance.SetGameState(GameState.Loading);
        StartCoroutine(LoadNextLevelDelayed(SceneManager.GetActiveScene().buildIndex));
    }

    public IEnumerator LoadNextLevelDelayed(int levelToLoad = -1)
    {
        yield return new WaitForSecondsRealtime(FadeController.Instance._fadeDuration * 1.25f);

        if (levelToLoad == -1)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
        }
        else
        {
            SceneManager.LoadScene(levelToLoad);
        }
    }
}
