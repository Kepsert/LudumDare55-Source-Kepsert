using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(CutsceneAction))]
public class CutsceneActionCustomEditor : Editor
{
    SerializedProperty _nameProp;
    SerializedProperty _hasDialogueProp;
    SerializedProperty _dialogue;

    SerializedProperty _fadeProp;
    SerializedProperty _screenToFadeProp;
    SerializedProperty _fadeInScreenProp;
    SerializedProperty _fadeOutScreenProp;
    SerializedProperty _fadeScreenDurationProp;

    SerializedProperty _moveTweenProp;
	SerializedProperty _objectToTweenProp;
    SerializedProperty _moveDistanceProp;
    SerializedProperty _moveTweenDurationProp;
    SerializedProperty _useEaseProp;

    SerializedProperty _triggerAnimationProp;
    SerializedProperty _animatorProp;
    SerializedProperty _animationNameProp;

    SerializedProperty _playSFXProp;
    SerializedProperty _sfxNameProp;

    SerializedProperty _playMusicProp;
    SerializedProperty _songNameProp;
    SerializedProperty _fadeOutMusicProp;
    SerializedProperty _FadeOutDurationProp;

    SerializedProperty _toggleGameObjectsProp;
    SerializedProperty _gameObjectsProp;

    SerializedProperty _changeGameStateProp;
    SerializedProperty _gameStateProp;

    SerializedProperty _loadLevelProp;
    SerializedProperty _levelToLoadProp;

    SerializedProperty _actionDurationProp;

    private void OnEnable()
    {
        _nameProp = serializedObject.FindProperty("_name");

        _hasDialogueProp = serializedObject.FindProperty("_hasDialogue");
        _dialogue = serializedObject.FindProperty("_dialogue");

        _fadeProp = serializedObject.FindProperty("_fade");
        _screenToFadeProp = serializedObject.FindProperty("_screenToFade");
        _fadeInScreenProp = serializedObject.FindProperty("_fadeInScreen");
        _fadeOutScreenProp = serializedObject.FindProperty("_fadeOutScreen");
        _fadeScreenDurationProp = serializedObject.FindProperty("_fadeScreenDuration");

        _moveTweenProp = serializedObject.FindProperty("_moveTween");
		_objectToTweenProp = serializedObject.FindProperty("_objectToTween");
        _moveDistanceProp = serializedObject.FindProperty("_moveDistance");
        _moveTweenDurationProp = serializedObject.FindProperty("_moveTweenDuration");
        _useEaseProp = serializedObject.FindProperty("_useEase");

        _triggerAnimationProp = serializedObject.FindProperty("_triggerAnimation");
        _animatorProp = serializedObject.FindProperty("_animatorTag");
        _animationNameProp = serializedObject.FindProperty("_animationName");

        _playSFXProp = serializedObject.FindProperty("_playSFX");
        _sfxNameProp = serializedObject.FindProperty("_sfxName");

        _playMusicProp = serializedObject.FindProperty("_playMusic");
        _songNameProp = serializedObject.FindProperty("_songName");
        _fadeOutMusicProp = serializedObject.FindProperty("_fadeOut");
        _FadeOutDurationProp = serializedObject.FindProperty("_fadeOutDuration");

        _toggleGameObjectsProp = serializedObject.FindProperty("_toggleGameObjects");
        _gameObjectsProp = serializedObject.FindProperty("_gameObjects");

        _changeGameStateProp = serializedObject.FindProperty("_changeGameState");
        _gameStateProp = serializedObject.FindProperty("_gameState");

        _loadLevelProp = serializedObject.FindProperty("_loadLevel");
        _levelToLoadProp = serializedObject.FindProperty("_levelToLoad");

        _actionDurationProp = serializedObject.FindProperty("_actionDuration");
    }

    public override void OnInspectorGUI()
    {
        serializedObject.Update();

        EditorGUILayout.PropertyField(_nameProp, new GUIContent("Name"));
        EditorGUILayout.PropertyField(_actionDurationProp, new GUIContent("Action Duration"));

        EditorGUILayout.PropertyField(_hasDialogueProp, new GUIContent("Has Dialogue"));
        if (_hasDialogueProp.boolValue)
        {
            EditorGUILayout.PropertyField(_dialogue, new GUIContent("Dialogue Trigger"));
        }

        EditorGUILayout.PropertyField(_fadeProp, new GUIContent("Fade Screen"));
        if (_fadeProp.boolValue)
        {
            EditorGUILayout.PropertyField(_screenToFadeProp, new GUIContent("Screen"));
            if (!_fadeOutScreenProp.boolValue)
            {
                EditorGUILayout.PropertyField(_fadeInScreenProp, new GUIContent("Fade In Screen CustomTag"));
            }
            else
            {
                _fadeInScreenProp.boolValue = false;
            }
            if (!_fadeInScreenProp.boolValue)
            {
                EditorGUILayout.PropertyField(_fadeOutScreenProp, new GUIContent("Fade Out Screen"));
            }
            else
            {
                _fadeOutScreenProp.boolValue = false;
            }
            EditorGUILayout.PropertyField(_fadeScreenDurationProp, new GUIContent("Fade Duration"));
        }

        EditorGUILayout.PropertyField(_moveTweenProp, new GUIContent("Move Tween"));
        if (_moveTweenProp.boolValue)
        {
			EditorGUILayout.PropertyField(_objectToTweenProp, new GUIContent("Object To Tween CustomTag"));
            EditorGUILayout.PropertyField(_moveDistanceProp, new GUIContent("Move Distance"));
            EditorGUILayout.PropertyField(_moveTweenDurationProp, new GUIContent("Move Duration"));
            EditorGUILayout.PropertyField(_useEaseProp, new GUIContent("Use Ease"));
        }

        EditorGUILayout.PropertyField(_triggerAnimationProp, new GUIContent("Trigger Animation"));
        if (_triggerAnimationProp.boolValue)
        {
            EditorGUILayout.PropertyField(_animatorProp, new GUIContent("Animator CustomTag"));
            EditorGUILayout.PropertyField(_animationNameProp, new GUIContent("Animation Name"));
        }

        EditorGUILayout.PropertyField(_playSFXProp, new GUIContent("Play SFX"));
        if (_playSFXProp.boolValue)
        {
            EditorGUILayout.PropertyField(_sfxNameProp, new GUIContent("SFX Name"));
        }

        EditorGUILayout.PropertyField(_playMusicProp, new GUIContent("Change Music"));
        if (_playMusicProp.boolValue)
        {
            EditorGUILayout.PropertyField(_songNameProp, new GUIContent("Song Name"));
            EditorGUILayout.PropertyField(_fadeOutMusicProp, new GUIContent("Fade Out"));
            if (_fadeOutMusicProp.boolValue)
            {
                EditorGUILayout.PropertyField(_FadeOutDurationProp, new GUIContent("Fade Duration"));
            }
        }

        EditorGUILayout.PropertyField(_toggleGameObjectsProp, new GUIContent("Toggle GameObjects"));
        if (_toggleGameObjectsProp.boolValue)
        {
            EditorGUILayout.PropertyField(_gameObjectsProp, new GUIContent("Game Object CustomTags"));
        }

        EditorGUILayout.PropertyField(_changeGameStateProp, new GUIContent("Change GameStates"));
        if (_changeGameStateProp.boolValue)
        {
            EditorGUILayout.PropertyField(_gameStateProp, new GUIContent("Game State"));
        }

        EditorGUILayout.PropertyField(_loadLevelProp, new GUIContent("Load Level"));
        if (_loadLevelProp.boolValue)
        {
            EditorGUILayout.PropertyField(_levelToLoadProp, new GUIContent("Level To Load"));
        }

        serializedObject.ApplyModifiedProperties();
    }
}
