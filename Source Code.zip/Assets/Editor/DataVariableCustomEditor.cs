using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(FloatVariable))]
public class FloatScriptableVariableCustomEditor : Editor
{
    public override void OnInspectorGUI()
    {
        base.OnInspectorGUI();

        FloatVariable floatScript = (FloatVariable)target;

        floatScript.ResetOnNewGame = EditorGUILayout.Toggle("Reset On New Game", floatScript.ResetOnNewGame);
        floatScript.ResetOnNewLevel = EditorGUILayout.Toggle("Reset On New Level", floatScript.ResetOnNewLevel);
        if (floatScript.ResetOnNewGame || floatScript.ResetOnNewLevel)
        {
            EditorGUILayout.Space(5);
            EditorGUILayout.LabelField("Default Value For This Data Object: ");
            EditorGUILayout.BeginHorizontal();
            floatScript.DefaultValue = EditorGUILayout.FloatField("Default Value", floatScript.DefaultValue);
            EditorGUILayout.EndHorizontal();
        }

        EditorGUILayout.Space(10);
        floatScript.SaveBetweenSessions = EditorGUILayout.Toggle("Save Between Sessions", floatScript.SaveBetweenSessions);
        if (floatScript.SaveBetweenSessions)
        {
            EditorGUILayout.Space(5);
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("Save Settings: ");
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.BeginHorizontal();
            floatScript.SaveInPlayerPrefs = EditorGUILayout.Toggle("Save In PlayerPrefs", floatScript.SaveInPlayerPrefs);
            EditorGUILayout.EndHorizontal();
            if (floatScript.SaveInPlayerPrefs)
            {
                EditorGUILayout.BeginHorizontal();
                floatScript.useCustomPlayerPrefsKey = EditorGUILayout.Toggle("Use Custom PlayerPrefs Key", floatScript.useCustomPlayerPrefsKey);
                EditorGUILayout.EndHorizontal();
                if (floatScript.useCustomPlayerPrefsKey)
                {
                    EditorGUILayout.BeginHorizontal();
                    floatScript.CustomPlayerPrefsKey = EditorGUILayout.TextField("Custom Player Prefs Key", floatScript.CustomPlayerPrefsKey);
                    EditorGUILayout.EndHorizontal();
                }
            }
        }
    }
}

[CustomEditor(typeof(StringVariable))]
public class StringScriptableVariableCustomEditor : Editor
{
    public override void OnInspectorGUI()
    {
        base.OnInspectorGUI();

        StringVariable stringScript = (StringVariable)target;

        stringScript.ResetOnNewGame = EditorGUILayout.Toggle("Reset On New Game", stringScript.ResetOnNewGame);
        stringScript.ResetOnNewLevel = EditorGUILayout.Toggle("Reset On New Level", stringScript.ResetOnNewLevel);
        if (stringScript.ResetOnNewGame || stringScript.ResetOnNewLevel)
        {
            EditorGUILayout.Space(5);
            EditorGUILayout.LabelField("Default Value For This Data Object: ");
            EditorGUILayout.BeginHorizontal();
            stringScript.DefaultValue = EditorGUILayout.TextField("Default Value", stringScript.DefaultValue);
            EditorGUILayout.EndHorizontal();
        }

        EditorGUILayout.Space(10);
        stringScript.SaveBetweenSessions = EditorGUILayout.Toggle("Save Between Sessions", stringScript.SaveBetweenSessions);
        if (stringScript.SaveBetweenSessions)
        {
            EditorGUILayout.Space(5);
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("Save Settings: ");
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.BeginHorizontal();
            stringScript.SaveInPlayerPrefs = EditorGUILayout.Toggle("Save In PlayerPrefs", stringScript.SaveInPlayerPrefs);
            EditorGUILayout.EndHorizontal();
            if (stringScript.SaveInPlayerPrefs)
            {
                EditorGUILayout.BeginHorizontal();
                stringScript.useCustomPlayerPrefsKey = EditorGUILayout.Toggle("Use Custom PlayerPrefs Key", stringScript.useCustomPlayerPrefsKey);
                EditorGUILayout.EndHorizontal();
                if (stringScript.useCustomPlayerPrefsKey)
                {
                    EditorGUILayout.BeginHorizontal();
                    stringScript.CustomPlayerPrefsKey = EditorGUILayout.TextField("Custom Player Prefs Key", stringScript.CustomPlayerPrefsKey);
                    EditorGUILayout.EndHorizontal();
                }
            }
        }
    }
}

[CustomEditor(typeof(BoolVariable))]
public class BoolScriptableVariableCustomEditor : Editor
{
    public override void OnInspectorGUI()
    {
        base.OnInspectorGUI();

        BoolVariable boolScript = (BoolVariable)target;

        boolScript.ResetOnNewGame = EditorGUILayout.Toggle("Reset On New Game", boolScript.ResetOnNewGame);
        boolScript.ResetOnNewLevel = EditorGUILayout.Toggle("Reset On New Level", boolScript.ResetOnNewLevel);
        if (boolScript.ResetOnNewGame || boolScript.ResetOnNewLevel)
        {
            EditorGUILayout.Space(5);
            EditorGUILayout.LabelField("Default Value For This Data Object: ");
            EditorGUILayout.BeginHorizontal();
            boolScript.DefaultValue = EditorGUILayout.Toggle("Default Value", boolScript.DefaultValue);
            EditorGUILayout.EndHorizontal();
        }

        EditorGUILayout.Space(10);
        boolScript.SaveBetweenSessions = EditorGUILayout.Toggle("Save Between Sessions", boolScript.SaveBetweenSessions);
        if (boolScript.SaveBetweenSessions)
        {
            EditorGUILayout.Space(5);
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("Save Settings: ");
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.BeginHorizontal();
            boolScript.SaveInPlayerPrefs = EditorGUILayout.Toggle("Save In PlayerPrefs", boolScript.SaveInPlayerPrefs);
            EditorGUILayout.EndHorizontal();
            if (boolScript.SaveInPlayerPrefs)
            {
                EditorGUILayout.BeginHorizontal();
                boolScript.useCustomPlayerPrefsKey = EditorGUILayout.Toggle("Use Custom PlayerPrefs Key", boolScript.useCustomPlayerPrefsKey);
                EditorGUILayout.EndHorizontal();
                if (boolScript.useCustomPlayerPrefsKey)
                {
                    EditorGUILayout.BeginHorizontal();
                    boolScript.CustomPlayerPrefsKey = EditorGUILayout.TextField("Custom Player Prefs Key", boolScript.CustomPlayerPrefsKey);
                    EditorGUILayout.EndHorizontal();
                }
            }
        }
    }
}