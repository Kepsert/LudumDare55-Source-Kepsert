using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(DialogueNodeSO))]
public class DialogueNodeCustomEditor : Editor
{
    SerializedProperty nameProp;
    SerializedProperty dialogueTextProp;
    SerializedProperty nextNodeProp;
    SerializedProperty hasDialogueOptionsProp;
    SerializedProperty choiceNodesProp;

    void OnEnable()
    {
        nameProp = serializedObject.FindProperty("_name");
        dialogueTextProp = serializedObject.FindProperty("_dialogueText");
        nextNodeProp = serializedObject.FindProperty("_nextNode");
        hasDialogueOptionsProp = serializedObject.FindProperty("HasDialogueOptions");
        choiceNodesProp = serializedObject.FindProperty("ChoiceNodeList");
        
    }

    public override void OnInspectorGUI()
    {
        serializedObject.Update();

        EditorGUILayout.PropertyField(nameProp, new GUIContent("Name"));
        EditorGUILayout.PropertyField(dialogueTextProp, new GUIContent("Dialogue Text"));
        EditorGUILayout.PropertyField(hasDialogueOptionsProp, new GUIContent("Has Dialogue Options"));

        if (hasDialogueOptionsProp.boolValue)
        {
            EditorGUILayout.Space(5);
            EditorGUILayout.LabelField("Dialogue Options: ");
            EditorGUILayout.PropertyField(choiceNodesProp, true);
        }
        if (!hasDialogueOptionsProp.boolValue)
        {
            EditorGUILayout.PropertyField(nextNodeProp, new GUIContent("Next Node"));
        }

        serializedObject.ApplyModifiedProperties();
    }
}
